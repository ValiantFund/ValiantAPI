"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-checkout.ts
var create_checkout_exports = {};
__export(create_checkout_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_checkout_exports);
var import_stripe = __toESM(require("stripe"), 1);
if (!process.env.VITE_STRIPE_SECRET_KEY) {
  throw new Error("Missing Stripe secret key");
}
var stripe = new import_stripe.default(process.env.VITE_STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16"
});
var handler = async (event) => {
  console.log("Received request:", {
    method: event.httpMethod,
    body: event.body
  });
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type"
      },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { priceId, userId, email } = JSON.parse(event.body || "");
    console.log("Creating checkout session:", { priceId, userId, email });
    if (!priceId || !userId || !email) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type"
        },
        body: JSON.stringify({
          error: "Missing required parameters",
          details: { priceId, userId, email }
        })
      };
    }
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      billing_address_collection: "required",
      line_items: [
        {
          price: priceId,
          quantity: 1
        }
      ],
      success_url: `${process.env.VITE_APP_URL}/dashboard/billing?success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.VITE_APP_URL}/dashboard/billing?canceled=true`,
      customer_email: email,
      client_reference_id: userId,
      allow_promotion_codes: true,
      subscription_data: {
        metadata: {
          userId
        },
        trial_period_days: 14
      },
      metadata: {
        userId
      },
      ui_mode: "hosted",
      custom_text: {
        submit: {
          message: "Your subscription will begin after a 14-day free trial"
        }
      }
    });
    console.log("Checkout session created:", session.id);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type"
      },
      body: JSON.stringify({ sessionId: session.id })
    };
  } catch (error) {
    console.error("Stripe checkout error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type"
      },
      body: JSON.stringify({
        error: error.message || "Failed to create checkout session"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=create-checkout.js.map
