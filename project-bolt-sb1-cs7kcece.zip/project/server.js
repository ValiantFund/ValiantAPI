import express from 'express';
import Stripe from 'stripe';
import dotenv from 'dotenv';
import cors from 'cors';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

if (!process.env.VITE_STRIPE_SECRET_KEY) {
  throw new Error('Missing Stripe secret key');
}

const stripe = new Stripe(process.env.VITE_STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16'
});

async function createServer() {
  const app = express();

  app.use(cors());
  app.use(express.json());

  app.post('/api/create-checkout-session', async (req, res) => {
    try {
      const { priceId, userId, email } = req.body;

      if (!priceId || !userId || !email) {
        return res.status(400).json({ 
          error: 'Missing required parameters',
          details: { priceId, userId, email }
        });
      }

      const baseUrl = process.env.VITE_APP_URL || 'http://localhost:3001';

      const session = await stripe.checkout.sessions.create({
        billing_address_collection: 'required',
        mode: 'subscription',
        payment_method_types: ['card'],
        line_items: [
          {
            price: priceId,
            quantity: 1,
          },
        ],
        success_url: `${baseUrl}/dashboard/billing?success=true&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${baseUrl}/dashboard/billing?canceled=true`,
        customer_email: email,
        client_reference_id: userId,
        allow_promotion_codes: true,
        subscription_data: {
          metadata: {
            userId,
          },
          trial_period_days: 14,
        },
        metadata: {
          userId,
        },
        ui_mode: 'hosted',
        custom_text: {
          submit: {
            message: 'Your subscription will begin after a 14-day free trial'
          }
        }
      });

      res.json({ sessionId: session.id });
    } catch (error) {
      console.error('Error creating checkout session:', error);
      res.status(500).json({ 
        error: error.message || 'Failed to create checkout session',
        code: error.code
      });
    }
  });

  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });

  app.use(vite.middlewares);

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(join(__dirname, 'dist', 'index.html'));
    });
  }

  const port = process.env.PORT || 3001;
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

createServer();