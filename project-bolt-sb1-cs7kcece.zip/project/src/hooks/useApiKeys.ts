import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';
import { getUserApiKeys, generateNewApiKey, initializeApiKeys } from '../services/apiKeyService';

export function useApiKeys() {
  const { user } = useAuth();
  const [apiKeys, setApiKeys] = useState<{
    production: string;
    test: string;
    productionUpdatedAt?: string;
    testUpdatedAt?: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadApiKeys();
    }
  }, [user]);

  const loadApiKeys = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      setError(null);
      const keys = await getUserApiKeys(user.uid);
      
      if (!keys) {
        const newKeys = await initializeApiKeys(user.uid);
        setApiKeys(newKeys);
      } else {
        setApiKeys(keys);
      }
    } catch (err) {
      console.error('Error loading API keys:', err);
      setError('Failed to load API keys');
    } finally {
      setLoading(false);
    }
  };

  const regenerateKey = async (type: 'production' | 'test') => {
    if (!user) throw new Error('User not authenticated');
    
    try {
      setError(null);
      const newKey = await generateNewApiKey(user.uid, type);
      setApiKeys(prev => prev ? {
        ...prev,
        [type]: newKey,
        [`${type}UpdatedAt`]: new Date().toISOString()
      } : null);
      return newKey;
    } catch (err) {
      console.error('Error regenerating key:', err);
      setError('Failed to generate new key');
      throw err;
    }
  };

  return {
    apiKeys,
    loading,
    error,
    regenerateKey,
    refresh: loadApiKeys
  };
}