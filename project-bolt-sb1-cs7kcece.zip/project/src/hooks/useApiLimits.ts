import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { FREE_TIER_LIMITS } from '../config/plans';

interface ApiUsage {
  calls: number;
  lastReset: string;
}

export function useApiLimits() {
  const { user } = useAuth();
  const [usage, setUsage] = useState<ApiUsage>({ calls: 0, lastReset: new Date().toISOString() });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchUsage() {
      if (!user) {
        setLoading(false);
        return;
      }

      try {
        const usageDoc = await getDoc(doc(db, 'usage', user.uid));
        const data = usageDoc.data() as ApiUsage;
        
        if (data) {
          // Check if we need to reset monthly usage
          const lastReset = new Date(data.lastReset);
          const now = new Date();
          if (lastReset.getMonth() !== now.getMonth()) {
            setUsage({ calls: 0, lastReset: now.toISOString() });
          } else {
            setUsage(data);
          }
        }
      } catch (err) {
        console.error('Error fetching API usage:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchUsage();
  }, [user]);

  const remainingCalls = FREE_TIER_LIMITS.apiCalls - usage.calls;
  const usagePercentage = (usage.calls / FREE_TIER_LIMITS.apiCalls) * 100;

  return {
    usage,
    remainingCalls,
    usagePercentage,
    loading,
    isOverLimit: usage.calls >= FREE_TIER_LIMITS.apiCalls
  };
}