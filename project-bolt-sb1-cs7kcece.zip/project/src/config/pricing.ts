export interface PricingPlan {
  id: string;
  name: string;
  basePrice: number;
  trialDays?: number;
  features: string[];
  apiCalls: {
    included: number;
    tiers: Array<{
      range: [number, number | null];
      rate: number;
    }>;
  };
  transactionFees: {
    included: number;
    rate: number;
  };
}

export const FREE_TRIAL_DURATION = 14;

export const PRICING_PLANS = {
  starter: {
    id: 'starter',
    name: 'Starter',
    basePrice: 99,
    trialDays: FREE_TRIAL_DURATION,
    features: [
      '100,000 included API calls/month',
      'Basic analytics',
      'Email support',
      '30 days data retention',
      'Standard security features'
    ],
    apiCalls: {
      included: 100_000,
      tiers: [
        { range: [100_001, 500_000], rate: 0.02 },
        { range: [500_001, null], rate: 0.015 }
      ]
    },
    transactionFees: {
      included: 100_000,
      rate: 0.0025
    }
  },
  professional: {
    id: 'professional',
    name: 'Professional',
    basePrice: 199,
    features: [
      '500,000 included API calls/month',
      'Advanced analytics',
      'Priority support',
      'Unlimited data retention',
      'Advanced security features',
      'Custom integrations'
    ],
    apiCalls: {
      included: 500_000,
      tiers: [
        { range: [500_001, 1_000_000], rate: 0.015 },
        { range: [1_000_001, null], rate: 0.01 }
      ]
    },
    transactionFees: {
      included: 500_000,
      rate: 0.002
    }
  },
  enterprise: {
    id: 'enterprise',
    name: 'Enterprise',
    basePrice: 999,
    features: [
      '2,000,000 included API calls/month',
      'Custom analytics',
      'Dedicated support',
      'Custom security features',
      'Priority infrastructure',
      'Custom SLAs'
    ],
    apiCalls: {
      included: 2_000_000,
      tiers: [
        { range: [2_000_001, null], rate: 0.005 }
      ]
    },
    transactionFees: {
      included: 2_000_000,
      rate: 0.0015
    }
  }
} as const;

export type PlanId = keyof typeof PRICING_PLANS;