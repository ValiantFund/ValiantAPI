import { db } from '../lib/firebase';
import { doc, setDoc, updateDoc, getDoc, runTransaction } from 'firebase/firestore';
import { generateApiKey } from '../lib/utils/apiKeyGenerator';
import { hashApiKey, generateKeyFingerprint } from '../lib/utils/crypto';

interface ApiKeys {
  production: string;
  test: string;
  productionUpdatedAt: string;
  testUpdatedAt: string;
  productionFingerprint?: string;
  testFingerprint?: string;
}

export async function generateNewApiKey(userId: string, type: 'production' | 'test'): Promise<string> {
  if (!userId) throw new Error('User ID is required');

  try {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);

    if (!userDoc.exists()) {
      throw new Error('User not found');
    }

    const newKey = generateApiKey(type);
    const keyHash = hashApiKey(newKey);
    const fingerprint = generateKeyFingerprint(newKey);
    const now = new Date().toISOString();

    await updateDoc(userRef, {
      [`apiKeys.${type}`]: newKey,
      [`apiKeys.${type}UpdatedAt`]: now,
      [`apiKeys.${type}Fingerprint`]: fingerprint
    });

    // Store key hash for validation
    await setDoc(doc(db, 'api_key_hashes', keyHash), {
      userId,
      type,
      createdAt: now,
      fingerprint
    });

    return newKey;
  } catch (error) {
    console.error('Error generating new API key:', error);
    throw new Error('Failed to generate new API key');
  }
}

export async function initializeApiKeys(userId: string): Promise<ApiKeys> {
  if (!userId) throw new Error('User ID is required');

  try {
    const userRef = doc(db, 'users', userId);
    const now = new Date().toISOString();

    const productionKey = generateApiKey('production');
    const testKey = generateApiKey('test');

    const initialKeys: ApiKeys = {
      production: productionKey,
      test: testKey,
      productionUpdatedAt: now,
      testUpdatedAt: now,
      productionFingerprint: generateKeyFingerprint(productionKey),
      testFingerprint: generateKeyFingerprint(testKey)
    };

    await setDoc(userRef, { apiKeys: initialKeys }, { merge: true });

    // Store key hashes
    await Promise.all([
      setDoc(doc(db, 'api_key_hashes', hashApiKey(productionKey)), {
        userId,
        type: 'production',
        createdAt: now
      }),
      setDoc(doc(db, 'api_key_hashes', hashApiKey(testKey)), {
        userId,
        type: 'test',
        createdAt: now
      })
    ]);

    return initialKeys;
  } catch (error) {
    console.error('Error initializing API keys:', error);
    throw new Error('Failed to initialize API keys');
  }
}

export async function getUserApiKeys(userId: string): Promise<ApiKeys | null> {
  if (!userId) return null;

  try {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      return null;
    }
    
    const data = userDoc.data();
    return data?.apiKeys || null;
  } catch (error) {
    console.error('Error fetching API keys:', error);
    throw new Error('Failed to fetch API keys');
  }
}