import React from 'react';
import { CreditCard, Building2, Shield, ArrowRight, Smartphone, Globe, ShoppingCart } from 'lucide-react';

const integrationExamples = [
  {
    title: "E-commerce Checkout",
    description: "Seamless payment processing for online stores",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=800&q=80",
    mockup: (
      <div className="bg-white rounded-lg shadow-lg p-4">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-gray-800 font-medium">Order Total</span>
            <span className="text-gray-900 font-bold">$129.99</span>
          </div>
          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="flex items-center space-x-3">
              <CreditCard className="w-5 h-5 text-purple-500" />
              <span className="text-gray-700">•••• 4242</span>
            </div>
          </div>
          <button className="w-full bg-purple-600 text-white py-2 rounded-lg">
            Complete Purchase
          </button>
        </div>
      </div>
    )
  },
  {
    title: "Mobile Banking",
    description: "Virtual accounts and transactions in your app",
    image: "https://images.unsplash.com/photo-1534237710431-e2fc698436d0?auto=format&fit=crop&w=800&q=80",
    mockup: (
      <div className="bg-gray-900 rounded-2xl p-4 text-white">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-gray-400 text-sm">Available Balance</p>
              <p className="text-2xl font-bold">$12,450.00</p>
            </div>
            <Smartphone className="w-6 h-6 text-purple-400" />
          </div>
          <div className="space-y-2">
            <div className="bg-gray-800 p-2 rounded-lg flex justify-between">
              <span>Netflix</span>
              <span className="text-red-400">-$14.99</span>
            </div>
            <div className="bg-gray-800 p-2 rounded-lg flex justify-between">
              <span>Salary</span>
              <span className="text-green-400">+$5,250.00</span>
            </div>
          </div>
        </div>
      </div>
    )
  },
  {
    title: "Business Dashboard",
    description: "Real-time financial analytics and reporting",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80",
    mockup: (
      <div className="bg-white rounded-lg p-4">
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="bg-purple-50 p-3 rounded-lg">
            <p className="text-purple-600 text-lg font-bold">$1.2M</p>
            <p className="text-gray-600 text-sm">Revenue</p>
          </div>
          <div className="bg-green-50 p-3 rounded-lg">
            <p className="text-green-600 text-lg font-bold">98.5%</p>
            <p className="text-gray-600 text-sm">Success Rate</p>
          </div>
          <div className="bg-blue-50 p-3 rounded-lg">
            <p className="text-blue-600 text-lg font-bold">12.5k</p>
            <p className="text-gray-600 text-sm">Transactions</p>
          </div>
        </div>
        <div className="h-20 bg-gray-50 rounded-lg"></div>
      </div>
    )
  },
  {
    title: "Global Marketplace",
    description: "Multi-currency support and international payments",
    image: "https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&w=800&q=80",
    mockup: (
      <div className="bg-white rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Globe className="w-5 h-5 text-purple-500 mr-2" />
            <span className="text-gray-800 font-medium">Global Payments</span>
          </div>
          <select className="bg-gray-50 border border-gray-200 rounded px-2 py-1">
            <option>USD</option>
            <option>EUR</option>
            <option>GBP</option>
          </select>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
            <span className="text-gray-600">Exchange Rate</span>
            <span className="text-gray-800">1 USD = 0.85 EUR</span>
          </div>
          <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
            <span className="text-gray-600">Processing Fee</span>
            <span className="text-gray-800">1.5%</span>
          </div>
        </div>
      </div>
    )
  }
];

export function ApiIntegrationExamples() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Integration Examples
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            See how our API seamlessly integrates into your applications
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {integrationExamples.map((example, index) => (
            <div key={index} className="bg-gray-800 rounded-xl overflow-hidden group hover:ring-2 hover:ring-purple-500 transition-all">
              <div className="h-64 relative">
                <img
                  src={example.image}
                  alt={example.title}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/60 to-transparent" />
                
                <div className="absolute inset-0 flex items-center justify-center p-6">
                  {example.mockup}
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-2xl font-semibold text-white mb-2">
                  {example.title}
                </h3>
                <p className="text-gray-400 mb-4">{example.description}</p>
                <button className="text-purple-400 hover:text-purple-300 inline-flex items-center">
                  <span>View Integration Guide</span>
                  <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}