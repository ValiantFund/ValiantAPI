import React from 'react';
import { Link } from 'react-router-dom';
import { Code2 } from 'lucide-react';
import { INTEGRATION_GUIDES } from './integrationData';

export function IntegrationButtons() {
  return (
    <div className="grid md:grid-cols-3 gap-6">
      {Object.entries(INTEGRATION_GUIDES).map(([key, guide]) => {
        const Icon = guide.icon;
        return (
          <Link
            key={key}
            to={`/integration/${key}`}
            className="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition-colors border border-gray-700 hover:border-purple-500 group"
          >
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-purple-500/10 p-3 rounded-lg group-hover:bg-purple-500/20 transition-colors">
                <Icon className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">
                  {guide.title}
                </h3>
                <p className="text-sm text-gray-400">
                  {guide.description}
                </p>
              </div>
            </div>
            <div className="flex items-center text-purple-400 text-sm">
              <span>View Integration Guide</span>
              <Code2 className="w-4 h-4 ml-2" />
            </div>
          </Link>
        );
      })}
    </div>
  );
}