import React from 'react';
import { ArrowLeft, Copy, Check } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import { Card } from '../common/Card';
import { Button } from '../common/Button';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { INTEGRATION_GUIDES, IntegrationType } from './integrationData';

export function IntegrationGuide() {
  const { platform } = useParams<{ platform: IntegrationType }>();
  const [copied, setCopied] = React.useState(false);
  
  const guide = platform ? INTEGRATION_GUIDES[platform] : null;
  
  if (!guide) {
    return (
      <div className="min-h-screen bg-gray-900 pt-24 px-6">
        <div className="container mx-auto">
          <Link to="/" className="text-gray-400 hover:text-white flex items-center mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Link>
          <h1 className="text-3xl font-bold text-white">Guide not found</h1>
        </div>
      </div>
    );
  }

  const Icon = guide.icon;

  const handleCopy = async (code: string) => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gray-900 pt-24 px-6">
      <div className="container mx-auto max-w-4xl">
        <Link to="/" className="text-gray-400 hover:text-white flex items-center mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <div className="flex items-center space-x-4 mb-8">
          <div className="bg-purple-500/10 p-4 rounded-lg">
            <Icon className="w-8 h-8 text-purple-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">{guide.title}</h1>
            <p className="text-gray-400">{guide.description}</p>
          </div>
        </div>

        <div className="space-y-8">
          {/* Prerequisites */}
          <Card title="Prerequisites">
            <ul className="space-y-3">
              {guide.prerequisites.map((prereq, index) => (
                <li key={index} className="flex items-start text-gray-300">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
                  {prereq}
                </li>
              ))}
            </ul>
          </Card>

          {/* Installation */}
          <Card title="Installation">
            <div className="relative">
              <SyntaxHighlighter
                language="bash"
                style={vscDarkPlus}
                className="rounded-lg"
              >
                {guide.installation}
              </SyntaxHighlighter>
              <button
                onClick={() => handleCopy(guide.installation)}
                className="absolute top-4 right-4 p-2 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-green-400" />
                ) : (
                  <Copy className="w-4 h-4 text-gray-400" />
                )}
              </button>
            </div>
          </Card>

          {/* Integration Steps */}
          <Card title="Integration Steps">
            <div className="space-y-6">
              {guide.steps.map((step, index) => (
                <div key={index}>
                  <h3 className="text-white font-semibold mb-3">
                    {index + 1}. {step.title}
                  </h3>
                  <p className="text-gray-400 mb-4">{step.description}</p>
                  <div className="relative">
                    <SyntaxHighlighter
                      language="javascript"
                      style={vscDarkPlus}
                      className="rounded-lg"
                    >
                      {step.code}
                    </SyntaxHighlighter>
                    <button
                      onClick={() => handleCopy(step.code)}
                      className="absolute top-4 right-4 p-2 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                    >
                      {copied ? (
                        <Check className="w-4 h-4 text-green-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Next Steps */}
          <Card title="Next Steps">
            <div className="space-y-6">
              <p className="text-gray-300">{guide.nextSteps}</p>
              <div className="flex space-x-4">
                <Button variant="primary">
                  View Documentation
                </Button>
                <Button variant="outline">
                  Join Community
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}