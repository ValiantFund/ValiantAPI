import { LucideIcon, Code2, Puzzle, Blocks } from 'lucide-react';

export interface IntegrationGuide {
  title: string;
  description: string;
  icon: LucideIcon;
  prerequisites: string[];
  installation: string;
  steps: {
    title: string;
    description: string;
    code: string;
  }[];
  nextSteps: string;
}

export const INTEGRATION_GUIDES: Record<string, IntegrationGuide> = {
  zapier: {
    title: 'Zapier Integration Guide',
    description: 'Connect Valiant API with 3000+ apps through Zapier',
    icon: Puzzle,
    prerequisites: [
      'A Valiant API account with API keys',
      'A Zapier account',
      'Basic understanding of Zapier workflows'
    ],
    installation: 'Visit zapier.com/apps/valiant/integrations to get started',
    steps: [
      {
        title: 'Connect Your Account',
        description: 'Add your Valiant API credentials to Zapier',
        code: `// Your API key from the dashboard
const apiKey = 'your_api_key_here';`
      },
      {
        title: 'Create a Zap',
        description: 'Set up your first automated workflow',
        code: `// Example webhook response format
{
  "event": "payment.success",
  "data": {
    "amount": 1000,
    "currency": "USD",
    "customer": "cus_123"
  }
}`
      }
    ],
    nextSteps: 'Explore our Zapier integration templates and create more advanced workflows.'
  },
  bubble: {
    title: 'Bubble.io Integration Guide',
    description: 'Build web apps with Valiant API without code',
    icon: Blocks,
    prerequisites: [
      'A Valiant API account',
      'A Bubble.io account',
      'Basic understanding of Bubble.io workflows'
    ],
    installation: 'Search for "Valiant API" in the Bubble.io plugin marketplace',
    steps: [
      {
        title: 'Install the Plugin',
        description: 'Add the Valiant API plugin to your Bubble app',
        code: `// Plugin configuration
{
  "api_key": "your_api_key",
  "environment": "production"
}`
      },
      {
        title: 'Create Workflows',
        description: 'Set up your first payment workflow',
        code: `// Example workflow action
bubble.payment.create({
  amount: 1000,
  currency: 'USD',
  customer: current_user.id
})`
      }
    ],
    nextSteps: 'Check out our Bubble.io templates and example applications.'
  },
  custom: {
    title: 'Custom Integration Guide',
    description: 'Build your own integration from scratch',
    icon: Code2,
    prerequisites: [
      'A Valiant API account',
      'Development environment setup',
      'Basic programming knowledge'
    ],
    installation: 'npm install @valiant/api',
    steps: [
      {
        title: 'Initialize Client',
        description: 'Set up the Valiant API client',
        code: `import { ValiantAPI } from '@valiant/api';

const client = new ValiantAPI('your_api_key');`
      },
      {
        title: 'Make API Calls',
        description: 'Start integrating API endpoints',
        code: `// Process a payment
const payment = await client.payments.create({
  amount: 1000,
  currency: 'USD',
  description: 'Test payment'
});`
      }
    ],
    nextSteps: 'Review our API documentation for more advanced integration options.'
  }
} as const;

export type IntegrationType = keyof typeof INTEGRATION_GUIDES;