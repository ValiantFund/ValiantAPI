import React from 'react';
import { Code2, Puzzle, Blocks } from 'lucide-react';

export const INTEGRATION_GUIDES = {
  zapier: {
    title: 'Zapier Integration',
    description: 'Connect with 3000+ apps through Zapier',
    icon: () => <Puzzle className="w-8 h-8 text-purple-400" />,
    documentation: 'https://zapier.com/apps/valiant/integrations',
    steps: [
      {
        title: 'Connect Your Account',
        description: 'Add your Valiant API credentials to Zapier',
        code: `// Your API key from the dashboard
const apiKey = 'your_api_key_here';`
      },
      {
        title: 'Create a Zap',
        description: 'Set up your first automated workflow',
        code: `// Example webhook response
{
  "event": "payment.success",
  "data": {
    "amount": 1000,
    "currency": "USD"
  }
}`
      }
    ]
  },
  bubble: {
    title: 'Bubble.io Integration',
    description: 'Build no-code apps with Valiant API',
    icon: () => <Blocks className="w-8 h-8 text-purple-400" />,
    documentation: 'https://bubble.io/plugin/valiant-api',
    steps: [
      {
        title: 'Install Plugin',
        description: 'Add Valiant API plugin to your Bubble app',
        code: `// Plugin configuration
{
  "api_key": "your_api_key",
  "environment": "production"
}`
      },
      {
        title: 'Create Workflow',
        description: 'Set up your first payment workflow',
        code: `// Example workflow
bubble.payment.create({
  amount: 1000,
  currency: 'USD'
})`
      }
    ]
  },
  custom: {
    title: 'Custom Integration',
    description: 'Build your own integration',
    icon: () => <Code2 className="w-8 h-8 text-purple-400" />,
    documentation: '/docs/api-reference',
    steps: [
      {
        title: 'Authentication',
        description: 'Initialize with your API key',
        code: `const valiant = new ValiantAPI('your_api_key');`
      },
      {
        title: 'Make API Calls',
        description: 'Start making API requests',
        code: `// Process a payment
const payment = await valiant.payments.create({
  amount: 1000,
  currency: 'USD'
});`
      }
    ]
  }
} as const;

export type IntegrationType = keyof typeof INTEGRATION_GUIDES;