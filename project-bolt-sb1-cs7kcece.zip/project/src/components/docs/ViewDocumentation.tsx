import React from 'react';
import { Link } from 'react-router-dom';
import { Code2, Book, Terminal, Shield, ArrowRight } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

const quickStartCode = `import { ValiantAPI } from '@valiant/api';

// Initialize the client
const valiant = new ValiantAPI('your_api_key');

// Process a payment
const payment = await valiant.payments.create({
  amount: 1000,
  currency: 'USD',
  description: 'Test payment'
});`;

export function ViewDocumentation() {
  const sections = [
    {
      icon: <Terminal className="w-8 h-8 text-purple-400" />,
      title: 'Quick Start',
      description: 'Get up and running with Valiant API in minutes.',
      link: '/dashboard/docs#quick-start'
    },
    {
      icon: <Code2 className="w-8 h-8 text-purple-400" />,
      title: 'API Reference',
      description: 'Detailed documentation for all API endpoints and services.',
      link: '/dashboard/docs#api-reference'
    },
    {
      icon: <Book className="w-8 h-8 text-purple-400" />,
      title: 'Guides & Tutorials',
      description: 'Step-by-step guides for implementing specific features.',
      link: '/dashboard/docs#guides'
    },
    {
      icon: <Shield className="w-8 h-8 text-purple-400" />,
      title: 'Security & Compliance',
      description: 'Best practices for secure integration and compliance.',
      link: '/dashboard/docs#security'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-24">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-white mb-6">
            Documentation
          </h1>
          <p className="text-xl text-gray-400 mb-12">
            Everything you need to know about integrating and using Valiant API.
          </p>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {sections.map((section, index) => (
              <Link
                key={index}
                to={section.link}
                className="bg-gray-800 rounded-xl p-6 hover:border-purple-500 border border-gray-700 transition-colors"
              >
                <div className="mb-4">{section.icon}</div>
                <h2 className="text-xl font-semibold text-white mb-2">{section.title}</h2>
                <p className="text-gray-400">{section.description}</p>
              </Link>
            ))}
          </div>

          <div className="bg-gray-800 rounded-xl p-8 mb-12">
            <h2 className="text-2xl font-semibold text-white mb-6">Quick Example</h2>
            <SyntaxHighlighter
              language="javascript"
              style={vscDarkPlus}
              className="rounded-lg"
            >
              {quickStartCode}
            </SyntaxHighlighter>
          </div>

          <div className="bg-purple-600 rounded-xl p-8">
            <h2 className="text-2xl font-semibold text-white mb-4">Need Help?</h2>
            <p className="text-purple-100 mb-6">
              Our support team is here to help you with any questions or issues.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/dashboard/docs"
                className="inline-flex items-center justify-center space-x-2 bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                <span>Full Documentation</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <a
                href="mailto:support@valiantapi.com"
                className="inline-flex items-center justify-center space-x-2 bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-800 transition-colors"
              >
                <span>Contact Support</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}