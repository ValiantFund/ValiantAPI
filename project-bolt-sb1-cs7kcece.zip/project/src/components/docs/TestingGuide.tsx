import React from 'react';
import { Code2, Bug, Beaker } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

const testingCode = `// Initialize test client
const client = createTestClient({ sandbox: true });

// Test payment processing
try {
  const payment = await client.payments.create({
    amount: 1000,
    currency: 'USD',
    description: 'Test payment',
    source: 'tok_visa'
  });
  console.log('Payment successful:', payment);
} catch (error) {
  console.error('Payment failed:', error);
}`;

const debuggingCode = `// Enable debug mode
const client = new ValiantAPI('your_test_key', {
  debug: true,
  timeout: 5000
});

// Debug logging will show:
// - Request details
// - Response data
// - Error information
// - Performance metrics`;

export function TestingGuide() {
  return (
    <div className="space-y-8">
      <section className="bg-gray-800 rounded-xl p-6">
        <div className="flex items-center mb-4">
          <Beaker className="w-6 h-6 text-purple-400 mr-3" />
          <h2 className="text-xl font-semibold text-white">Test Environment</h2>
        </div>
        <p className="text-gray-300 mb-4">
          Use our sandbox environment to test your integration without affecting production data.
        </p>
        <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
          {testingCode}
        </SyntaxHighlighter>
      </section>

      <section className="bg-gray-800 rounded-xl p-6">
        <div className="flex items-center mb-4">
          <Bug className="w-6 h-6 text-purple-400 mr-3" />
          <h2 className="text-xl font-semibold text-white">Debugging</h2>
        </div>
        <p className="text-gray-300 mb-4">
          Enable debug mode to get detailed logs of API requests and responses.
        </p>
        <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
          {debuggingCode}
        </SyntaxHighlighter>
      </section>

      <section className="bg-gray-800 rounded-xl p-6">
        <div className="flex items-center mb-4">
          <Code2 className="w-6 h-6 text-purple-400 mr-3" />
          <h2 className="text-xl font-semibold text-white">Test Cards</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-gray-900 p-4 rounded-lg">
            <h3 className="text-white font-medium mb-2">Successful Payment</h3>
            <code className="text-gray-300">4242 4242 4242 4242</code>
          </div>
          <div className="bg-gray-900 p-4 rounded-lg">
            <h3 className="text-white font-medium mb-2">Declined Payment</h3>
            <code className="text-gray-300">4000 0000 0000 0002</code>
          </div>
        </div>
      </section>
    </div>
  );
}