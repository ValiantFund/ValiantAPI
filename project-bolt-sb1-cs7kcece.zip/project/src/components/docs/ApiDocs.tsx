import React from 'react';
import { Editor } from '@monaco-editor/react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

const codeExamples = {
  payments: `
// Initialize the Valiant API client
const valiant = new ValiantAPI('your-api-key');

// Create a payment
const payment = await valiant.payments.create({
  amount: 1000, // Amount in cents
  currency: 'USD',
  description: 'Test payment',
  source: 'tok_visa'
});`,
  lending: `
// Initialize lending service
const loan = await valiant.lending.create({
  amount: 5000,
  term: 12, // months
  type: 'working_capital',
  businessId: 'bus_123'
});`,
  banking: `
// Create a virtual account
const account = await valiant.banking.createAccount({
  type: 'business',
  currency: 'USD',
  businessName: 'Acme Inc'
});`
};

export function ApiDocs() {
  return (
    <section id="developers" className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Developer Documentation
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Integrate our APIs with just a few lines of code
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-bold text-white mb-6">Quick Start</h3>
            <div className="bg-gray-800 rounded-xl p-6">
              <SyntaxHighlighter
                language="javascript"
                style={vscDarkPlus}
                className="rounded-lg"
              >
                {codeExamples.payments}
              </SyntaxHighlighter>
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-white mb-6">Interactive Playground</h3>
            <div className="bg-gray-800 rounded-xl p-6 h-[300px]">
              <Editor
                height="100%"
                defaultLanguage="javascript"
                defaultValue={codeExamples.banking}
                theme="vs-dark"
                options={{
                  minimap: { enabled: false },
                  fontSize: 14,
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}