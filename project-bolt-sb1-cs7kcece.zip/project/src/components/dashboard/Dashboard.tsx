import React from 'react';
import { useAuth } from '../auth/AuthContext';
import { 
  Activity, 
  Users, 
  DollarSign, 
  ArrowUpRight,
  ArrowDownRight,
  Code,
  Zap,
  LineChart,
  Clock
} from 'lucide-react';
import { Link } from 'react-router-dom';

export function Dashboard() {
  const { user } = useAuth();

  const stats = [
    {
      label: 'API Calls',
      value: '2.4M',
      change: '+12.5%',
      isPositive: true,
      icon: <Activity className="w-6 h-6 text-purple-400" />
    },
    {
      label: 'Active Users',
      value: '1,234',
      change: '+8.2%',
      isPositive: true,
      icon: <Users className="w-6 h-6 text-purple-400" />
    },
    {
      label: 'Revenue',
      value: '$12.5k',
      change: '-2.4%',
      isPositive: false,
      icon: <DollarSign className="w-6 h-6 text-purple-400" />
    }
  ];

  const recentActivity = [
    { type: 'payment', message: 'Payment processed', amount: '$2,500', time: '2m ago' },
    { type: 'api', message: 'New API key generated', amount: '', time: '15m ago' },
    { type: 'user', message: 'New user registered', amount: '', time: '1h ago' },
    { type: 'payment', message: 'Subscription renewed', amount: '$199', time: '2h ago' }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 rounded-xl p-8">
        <h1 className="text-3xl font-bold text-white mb-2">
          Welcome back, {user?.displayName || 'Developer'}
        </h1>
        <p className="text-purple-100">
          Here's what's happening with your API integration
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition-colors">
            <div className="flex items-center justify-between mb-4">
              {stat.icon}
              <span className={`flex items-center ${
                stat.isPositive ? 'text-green-400' : 'text-red-400'
              }`}>
                {stat.isPositive ? (
                  <ArrowUpRight className="w-4 h-4 mr-1" />
                ) : (
                  <ArrowDownRight className="w-4 h-4 mr-1" />
                )}
                {stat.change}
              </span>
            </div>
            <h3 className="text-gray-400 text-sm mb-1">{stat.label}</h3>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Link to="/dashboard/api-keys" className="bg-gray-800 p-6 rounded-xl hover:bg-gray-750 transition-colors group">
          <div className="flex items-center space-x-4">
            <div className="bg-purple-500/10 p-3 rounded-lg group-hover:bg-purple-500/20 transition-colors">
              <Code className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-white font-semibold">API Keys</h3>
              <p className="text-gray-400 text-sm">Manage access</p>
            </div>
          </div>
        </Link>
        <Link to="/dashboard/docs" className="bg-gray-800 p-6 rounded-xl hover:bg-gray-750 transition-colors group">
          <div className="flex items-center space-x-4">
            <div className="bg-purple-500/10 p-3 rounded-lg group-hover:bg-purple-500/20 transition-colors">
              <Zap className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Documentation</h3>
              <p className="text-gray-400 text-sm">Learn & build</p>
            </div>
          </div>
        </Link>
        <Link to="/dashboard/analytics" className="bg-gray-800 p-6 rounded-xl hover:bg-gray-750 transition-colors group">
          <div className="flex items-center space-x-4">
            <div className="bg-purple-500/10 p-3 rounded-lg group-hover:bg-purple-500/20 transition-colors">
              <LineChart className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Analytics</h3>
              <p className="text-gray-400 text-sm">View insights</p>
            </div>
          </div>
        </Link>
        <Link to="/dashboard/billing" className="bg-gray-800 p-6 rounded-xl hover:bg-gray-750 transition-colors group">
          <div className="flex items-center space-x-4">
            <div className="bg-purple-500/10 p-3 rounded-lg group-hover:bg-purple-500/20 transition-colors">
              <DollarSign className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Billing</h3>
              <p className="text-gray-400 text-sm">Manage plan</p>
            </div>
          </div>
        </Link>
      </div>

      {/* Recent Activity */}
      <div className="bg-gray-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-white">Recent Activity</h2>
          <Link to="/dashboard/analytics" className="text-purple-400 hover:text-purple-300 text-sm">
            View all
          </Link>
        </div>
        <div className="space-y-4">
          {recentActivity.map((activity, index) => (
            <div key={index} className="flex items-center justify-between py-3 border-b border-gray-700 last:border-0">
              <div className="flex items-center space-x-4">
                <div className="bg-purple-500/10 p-2 rounded-lg">
                  <Clock className="w-4 h-4 text-purple-400" />
                </div>
                <div>
                  <p className="text-white">{activity.message}</p>
                  <p className="text-sm text-gray-400">{activity.time}</p>
                </div>
              </div>
              {activity.amount && (
                <span className="text-white font-medium">{activity.amount}</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Getting Started */}
      <div className="bg-gray-800 rounded-xl p-6">
        <h2 className="text-xl font-semibold text-white mb-4">Getting Started</h2>
        <div className="bg-gray-900 p-4 rounded-lg mb-4">
          <pre className="text-gray-300 font-mono text-sm overflow-x-auto">
            <code>{`// Initialize Valiant API
const valiant = new ValiantAPI('${user?.uid ? 'your_api_key' : 'API_KEY_HERE'}');

// Make your first API call
const payment = await valiant.payments.create({
  amount: 1000,
  currency: 'USD'
});`}</code>
          </pre>
        </div>
        <Link 
          to="/dashboard/docs" 
          className="text-purple-400 hover:text-purple-300 inline-flex items-center"
        >
          <Code className="w-4 h-4 mr-2" />
          View Full Documentation
        </Link>
      </div>
    </div>
  );
}