import React from 'react';
import { Card } from '../common/Card';
import { Activity, Users, DollarSign, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  change: string;
  isPositive: boolean;
  icon: React.ReactNode;
}

function StatCard({ label, value, change, isPositive, icon }: StatCardProps) {
  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        {icon}
        <span className={`flex items-center ${
          isPositive ? 'text-green-400' : 'text-red-400'
        }`}>
          {isPositive ? (
            <ArrowUpRight className="w-4 h-4 mr-1" />
          ) : (
            <ArrowDownRight className="w-4 h-4 mr-1" />
          )}
          {change}
        </span>
      </div>
      <h3 className="text-gray-400 text-sm mb-1">{label}</h3>
      <p className="text-2xl font-bold text-white">{value}</p>
    </Card>
  );
}

export function DashboardStats() {
  const stats = [
    {
      label: 'API Calls',
      value: '2.4M',
      change: '+12.5%',
      isPositive: true,
      icon: <Activity className="w-6 h-6 text-purple-400" />
    },
    {
      label: 'Active Users',
      value: '1,234',
      change: '+8.2%',
      isPositive: true,
      icon: <Users className="w-6 h-6 text-purple-400" />
    },
    {
      label: 'Revenue',
      value: '$12.5k',
      change: '-2.4%',
      isPositive: false,
      icon: <DollarSign className="w-6 h-6 text-purple-400" />
    }
  ];

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {stats.map((stat, index) => (
        <StatCard key={index} {...stat} />
      ))}
    </div>
  );
}