import React from 'react';
import { PRICING_PLANS } from '../../config/pricing';
import { PricingPlanCard } from './PricingPlanCard';
import { Shield } from 'lucide-react';

export function PricingPlans() {
  return (
    <section id="pricing" className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-gray-400 mb-2">
            Start with a base plan and only pay for what you use
          </p>
          <p className="text-purple-400">
            Try our Starter plan with a 14-day free trial
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {(Object.keys(PRICING_PLANS) as Array<keyof typeof PRICING_PLANS>).map((planId) => (
            <PricingPlanCard key={planId} planId={planId} />
          ))}
        </div>

        <div className="mt-16 max-w-3xl mx-auto">
          <div className="bg-gray-800 rounded-xl p-8">
            <div className="flex items-center mb-6">
              <Shield className="w-8 h-8 text-purple-400 mr-4" />
              <h3 className="text-xl font-semibold text-white">
                Enterprise Security & Compliance
              </h3>
            </div>
            <div className="grid md:grid-cols-2 gap-6 text-gray-300">
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2" />
                  SOC 2 Type II Certified
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2" />
                  GDPR Compliant
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2" />
                  99.99% Uptime SLA
                </li>
              </ul>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2" />
                  24/7 Enterprise Support
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2" />
                  Dedicated Account Manager
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2" />
                  Custom Contract Terms
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}