import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Check } from 'lucide-react';
import { solutionDetails } from './solutionData';

export function SolutionDetail() {
  const { id } = useParams();
  const solution = solutionDetails[id as keyof typeof solutionDetails];

  if (!solution) {
    return (
      <div className="min-h-screen bg-gray-900 pt-24 px-6">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-white">Solution not found</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 pt-24 px-6">
      <div className="container mx-auto">
        <Link
          to="/#solutions"
          className="inline-flex items-center text-gray-400 hover:text-white mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Solutions
        </Link>

        <div className="max-w-4xl">
          <div className="mb-12">
            <div className="flex items-center mb-6">
              {solution.icon}
              <h1 className="text-4xl font-bold text-white ml-4">{solution.title}</h1>
            </div>
            <p className="text-xl text-gray-400">{solution.description}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-gray-800 rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-white mb-6">Key Features</h2>
              <ul className="space-y-4">
                {solution.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="w-5 h-5 text-purple-400 mt-1 mr-3 flex-shrink-0" />
                    <span className="text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-gray-800 rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-white mb-6">Integration Steps</h2>
              <ol className="space-y-4">
                {solution.integrationSteps.map((step, index) => (
                  <li key={index} className="flex">
                    <span className="w-6 h-6 rounded-full bg-purple-500 text-white flex items-center justify-center mr-3 flex-shrink-0">
                      {index + 1}
                    </span>
                    <span className="text-gray-300">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          <div className="bg-gray-800 rounded-xl p-8 mb-12">
            <h2 className="text-2xl font-semibold text-white mb-6">Code Example</h2>
            <pre className="bg-gray-900 p-6 rounded-lg overflow-x-auto">
              <code className="text-gray-300 font-mono text-sm">{solution.codeExample}</code>
            </pre>
          </div>

          <div className="bg-purple-600 rounded-xl p-8 text-center">
            <h2 className="text-2xl font-semibold text-white mb-4">Ready to get started?</h2>
            <p className="text-purple-100 mb-6">
              Start integrating {solution.title} solutions into your platform today.
            </p>
            <Link
              to="/signup"
              className="inline-block bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Create Account
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}