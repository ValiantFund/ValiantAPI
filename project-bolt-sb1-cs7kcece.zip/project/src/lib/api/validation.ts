import { z } from 'zod';

// Common schemas
const currencySchema = z.enum(['USD', 'EUR', 'GBP', 'JPY']);
const amountSchema = z.number().positive().int();
const metadataSchema = z.record(z.string()).optional();

// Payment validation schemas
export const createPaymentSchema = z.object({
  amount: amountSchema,
  currency: currencySchema,
  description: z.string().min(1).max(255),
  source: z.string(),
  metadata: metadataSchema
});

// Lending validation schemas
export const createLoanSchema = z.object({
  amount: amountSchema,
  term: z.number().int().positive().max(120), // Max 10 years
  type: z.enum(['working_capital', 'invoice_financing', 'equipment']),
  businessId: z.string(),
  metadata: metadataSchema
});

// Banking validation schemas
export const createAccountSchema = z.object({
  type: z.enum(['business', 'individual']),
  currency: currencySchema,
  businessName: z.string().min(1).max(255).optional(),
  individualName: z.string().min(1).max(255).optional()
});

// Insurance validation schemas
export const createQuoteSchema = z.object({
  type: z.enum(['product', 'travel', 'credit']),
  coverage: amountSchema,
  productValue: amountSchema.optional(),
  duration: z.number().int().positive(),
  metadata: metadataSchema
});

// Compliance validation schemas
export const verificationSchema = z.object({
  type: z.enum(['individual', 'business']),
  data: z.object({
    name: z.string().min(1).max(255),
    taxId: z.string().optional(),
    dateOfBirth: z.string().optional(),
    address: z.object({
      street: z.string(),
      city: z.string(),
      country: z.string().length(2), // ISO country code
      postalCode: z.string()
    }).optional()
  })
});

// Error response schema
export const errorResponseSchema = z.object({
  code: z.string(),
  message: z.string(),
  details: z.array(z.string()).optional()
});

// Validation middleware
export function validateRequest<T>(schema: z.Schema<T>) {
  return (data: unknown): { success: true; data: T } | { success: false; error: string } => {
    try {
      const validated = schema.parse(data);
      return { success: true, data: validated };
    } catch (error) {
      if (error instanceof z.ZodError) {
        return {
          success: false,
          error: error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')
        };
      }
      return { success: false, error: 'Invalid request data' };
    }
  };
}

// Format API response
export function formatResponse<T>(data: T) {
  return {
    success: true,
    data,
    timestamp: new Date().toISOString()
  };
}

// Format error response
export function formatError(code: string, message: string, details?: string[]) {
  return {
    success: false,
    error: {
      code,
      message,
      details
    },
    timestamp: new Date().toISOString()
  };
}