import { makeRequest } from './base';

export interface VerificationResult {
  id: string;
  status: 'pending' | 'approved' | 'rejected';
  type: 'kyc' | 'aml' | 'sanctions';
  created: string;
}

export interface VerificationParams {
  type: 'individual' | 'business';
  data: {
    name: string;
    taxId?: string;
    dateOfBirth?: string;
    address?: {
      street: string;
      city: string;
      country: string;
      postalCode: string;
    };
  };
}

export function compliance(apiKey: string) {
  return {
    verify: async (params: VerificationParams): Promise<VerificationResult> => {
      return makeRequest(apiKey, '/compliance/verify', 'POST', params);
    },

    checkStatus: async (verificationId: string): Promise<VerificationResult> => {
      return makeRequest(apiKey, `/compliance/verify/${verificationId}`);
    },

    getReport: async (verificationId: string) => {
      return makeRequest(apiKey, `/compliance/verify/${verificationId}/report`);
    },
  };
}