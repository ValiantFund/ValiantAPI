import { makeRequest } from './base';

export interface Policy {
  id: string;
  type: 'product' | 'travel' | 'credit';
  status: 'active' | 'expired' | 'cancelled';
  premium: number;
  coverage: number;
}

export interface CreatePolicyParams {
  type: 'product' | 'travel' | 'credit';
  coverage: number;
  duration: number;
  metadata?: Record<string, string>;
}

export function insurance(apiKey: string) {
  return {
    createPolicy: async (params: CreatePolicyParams): Promise<Policy> => {
      return makeRequest(apiKey, '/insurance/policies', 'POST', params);
    },

    getQuote: async (params: CreatePolicyParams) => {
      return makeRequest(apiKey, '/insurance/quote', 'POST', params);
    },

    fileClaim: async (policyId: string, claimDetails: any) => {
      return makeRequest(apiKey, `/insurance/policies/${policyId}/claims`, 'POST', claimDetails);
    },
  };
}