import { payments } from './payments';
import { lending } from './lending';
import { banking } from './banking';
import { insurance } from './insurance';
import { compliance } from './compliance';

export class ValiantAPI {
  private apiKey: string;
  public payments: typeof payments;
  public lending: typeof lending;
  public banking: typeof banking;
  public insurance: typeof insurance;
  public compliance: typeof compliance;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
    this.payments = payments(apiKey);
    this.lending = lending(apiKey);
    this.banking = banking(apiKey);
    this.insurance = insurance(apiKey);
    this.compliance = compliance(apiKey);
  }
}

export type { Payment } from './payments';
export type { Loan } from './lending';
export type { Account } from './banking';
export type { Policy } from './insurance';
export type { VerificationResult } from './compliance';