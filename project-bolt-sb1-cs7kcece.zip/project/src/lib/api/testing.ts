import { ValiantAPI } from './index';

// Test API keys
export const TEST_API_KEYS = {
  test: 'test_sk_1234567890abcdef',
  production: 'live_sk_1234567890abcdef'
};

// Mock responses for testing
export const mockResponses = {
  payments: {
    success: {
      id: 'pay_test123',
      amount: 1000,
      currency: 'USD',
      status: 'succeeded',
      created: new Date().toISOString()
    },
    error: {
      code: 'card_declined',
      message: 'The card was declined',
      details: ['Insufficient funds']
    }
  },
  lending: {
    success: {
      id: 'loan_test123',
      amount: 50000,
      term: 12,
      status: 'approved',
      interestRate: 6.5,
      created: new Date().toISOString()
    }
  },
  banking: {
    success: {
      id: 'acct_test123',
      type: 'business',
      currency: 'USD',
      balance: 10000,
      status: 'active'
    }
  }
};

// Test client factory
export function createTestClient(options: { sandbox?: boolean } = {}) {
  const apiKey = options.sandbox ? TEST_API_KEYS.test : TEST_API_KEYS.production;
  return new ValiantAPI(apiKey);
}

// Test helper functions
export const testHelpers = {
  createPayment: async (amount: number, currency: string = 'USD') => {
    const client = createTestClient({ sandbox: true });
    return await client.payments.create({
      amount,
      currency,
      description: 'Test payment',
      source: 'tok_visa'
    });
  },
  
  createLoan: async (amount: number, term: number = 12) => {
    const client = createTestClient({ sandbox: true });
    return await client.lending.create({
      amount,
      term,
      type: 'working_capital',
      businessId: 'bus_test123'
    });
  },
  
  createBankAccount: async () => {
    const client = createTestClient({ sandbox: true });
    return await client.banking.createAccount({
      type: 'business',
      currency: 'USD',
      businessName: 'Test Business'
    });
  }
};