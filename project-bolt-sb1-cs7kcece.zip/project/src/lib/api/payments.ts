import { makeRequest } from './base';

export interface Payment {
  id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'succeeded' | 'failed';
  created: string;
}

export interface CreatePaymentParams {
  amount: number;
  currency: string;
  description?: string;
  metadata?: Record<string, string>;
}

export function payments(apiKey: string) {
  return {
    create: async (params: CreatePaymentParams): Promise<Payment> => {
      return makeRequest(apiKey, '/payments', 'POST', params);
    },

    retrieve: async (paymentId: string): Promise<Payment> => {
      return makeRequest(apiKey, `/payments/${paymentId}`);
    },

    list: async (params?: { limit?: number; starting_after?: string }) => {
      return makeRequest(apiKey, '/payments', 'GET', params);
    },
  };
}