import { makeRequest } from './base';

export interface Loan {
  id: string;
  amount: number;
  term: number;
  status: 'pending' | 'approved' | 'rejected' | 'active';
  interestRate: number;
  created: string;
}

export interface CreateLoanParams {
  amount: number;
  term: number;
  type: 'working_capital' | 'invoice_financing' | 'equipment';
  businessId: string;
}

export function lending(apiKey: string) {
  return {
    create: async (params: CreateLoanParams): Promise<Loan> => {
      return makeRequest(apiKey, '/lending/loans', 'POST', params);
    },

    retrieve: async (loanId: string): Promise<Loan> => {
      return makeRequest(apiKey, `/lending/loans/${loanId}`);
    },

    getDecision: async (applicationId: string) => {
      return makeRequest(apiKey, `/lending/decisions/${applicationId}`);
    },
  };
}