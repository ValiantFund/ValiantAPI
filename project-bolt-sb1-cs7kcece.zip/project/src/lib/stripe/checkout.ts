import { stripePromise } from './config';
import { createCheckoutSession } from './api';
import { CreateCheckoutSessionParams } from './types';
import { handleCheckoutError } from './errors';

export async function redirectToCheckout(params: CreateCheckoutSessionParams): Promise<void> {
  try {
    const { sessionId } = await createCheckoutSession(params);

    const stripe = await stripePromise;
    if (!stripe) {
      throw new Error('Stripe not initialized');
    }

    const { error } = await stripe.redirectToCheckout({ sessionId });
    if (error) {
      console.error('Stripe redirect error:', error);
      throw error;
    }
  } catch (error) {
    handleCheckoutError(error);
  }
}