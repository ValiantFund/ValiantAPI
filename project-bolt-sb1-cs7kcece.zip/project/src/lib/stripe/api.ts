import { CreateCheckoutSessionParams, CheckoutSession } from './types';
import { CheckoutError } from './errors';

export async function createCheckoutSession(params: CreateCheckoutSessionParams): Promise<CheckoutSession> {
  try {
    console.log('Creating checkout session:', { 
      priceId: params.priceId, 
      userId: params.userId 
    });

    const response = await fetch('/.netlify/functions/create-checkout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new CheckoutError(
        errorData.error || 'Failed to create checkout session',
        errorData.code,
        errorData.details
      );
    }

    const data = await response.json();
    
    if (!data.sessionId) {
      throw new CheckoutError('Invalid response: missing session ID');
    }

    console.log('Checkout session created:', data.sessionId);
    return { sessionId: data.sessionId };
  } catch (error) {
    console.error('API error:', error);
    if (error instanceof CheckoutError) {
      throw error;
    }
    throw new CheckoutError('Failed to create checkout session');
  }
}