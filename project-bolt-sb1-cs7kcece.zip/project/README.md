# Valiant API Platform

A comprehensive financial API platform offering embedded finance solutions including payments, lending, banking, insurance, and compliance services.

## Features

- Global payment processing
- Lending and credit solutions
- Virtual banking services
- Insurance products
- Compliance and KYC tools
- Real-time analytics
- Developer-friendly documentation

## Tech Stack

- React
- TypeScript
- Tailwind CSS
- Stripe Integration
- Firebase Authentication
- Netlify Deployment

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run Netlify Functions locally
npm run functions:dev
```

## Environment Variables

Create a `.env` file in the root directory with the following variables:

```env
VITE_STRIPE_PUBLIC_KEY=your_stripe_public_key
VITE_STRIPE_SECRET_KEY=your_stripe_secret_key
VITE_APP_URL=your_app_url
```

## License

MIT