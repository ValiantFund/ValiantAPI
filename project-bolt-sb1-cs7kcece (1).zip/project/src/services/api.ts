import { auth } from '../lib/firebase';

export async function createCheckoutSession(priceId: string) {
  if (!auth.currentUser) {
    throw new Error('User must be authenticated');
  }

  try {
    const response = await fetch('/api/create-checkout-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        priceId,
        userId: auth.currentUser.uid,
        email: auth.currentUser.email,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to create checkout session');
    }

    const data = await response.json();
    return data;
  } catch (error: any) {
    console.error('Checkout session creation error:', error);
    throw new Error(error.message || 'Failed to start checkout process');
  }
}