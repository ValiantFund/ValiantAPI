import { db } from '../lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  serverTimestamp,
  DocumentData 
} from 'firebase/firestore';

// Collection names
const COLLECTIONS = {
  USERS: 'users',
  API_KEYS: 'api_keys',
  USAGE: 'usage'
} as const;

// User data interface
interface UserData {
  email: string;
  createdAt: any;
  apiKeys?: {
    production: string;
    test: string;
    productionUpdatedAt: string;
    testUpdatedAt: string;
  };
  subscription?: {
    plan: string;
    status: string;
    currentPeriodEnd: string;
  };
}

// Create or update user data
export async function setUserData(userId: string, data: Partial<UserData>) {
  try {
    const userRef = doc(db, COLLECTIONS.USERS, userId);
    const userData = {
      ...data,
      updatedAt: serverTimestamp()
    };

    await setDoc(userRef, userData, { merge: true });
    return true;
  } catch (error) {
    console.error('Error setting user data:', error);
    throw new Error('Failed to update user data');
  }
}

// Get user data
export async function getUserData(userId: string): Promise<UserData | null> {
  try {
    const userRef = doc(db, COLLECTIONS.USERS, userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      return null;
    }
    
    return userDoc.data() as UserData;
  } catch (error) {
    console.error('Error getting user data:', error);
    throw new Error('Failed to fetch user data');
  }
}

// Update API key
export async function updateApiKey(userId: string, type: 'production' | 'test', key: string) {
  try {
    const userRef = doc(db, COLLECTIONS.USERS, userId);
    const updates = {
      [`apiKeys.${type}`]: key,
      [`apiKeys.${type}UpdatedAt`]: new Date().toISOString(),
      updatedAt: serverTimestamp()
    };
    
    await updateDoc(userRef, updates);
    return true;
  } catch (error) {
    console.error('Error updating API key:', error);
    throw new Error('Failed to update API key');
  }
}

// Track API usage
export async function trackApiUsage(userId: string, endpoint: string) {
  try {
    const usageRef = doc(db, COLLECTIONS.USAGE, userId);
    const now = new Date();
    const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    
    await updateDoc(usageRef, {
      [`usage.${monthKey}.total`]: increment(1),
      [`usage.${monthKey}.endpoints.${endpoint}`]: increment(1),
      lastUpdated: serverTimestamp()
    });
    
    return true;
  } catch (error) {
    console.error('Error tracking API usage:', error);
    throw new Error('Failed to track API usage');
  }
}