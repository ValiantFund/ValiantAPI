export const FREE_TRIAL_DURATION = 14; // days

export const PRICING_TIERS = {
  starter: {
    id: 'starter',
    name: 'Starter',
    price: 49,
    priceId: 'price_starter123',
    trialDays: FREE_TRIAL_DURATION,
    features: [
      '50,000 API calls/month',
      'Unlimited endpoints',
      'Advanced analytics',
      'Email support',
      '30 days data retention',
      'Private documentation',
      'Custom domain'
    ]
  },
  professional: {
    id: 'professional',
    name: 'Professional',
    price: 199,
    priceId: 'price_pro123',
    features: [
      'Unlimited API calls',
      'Priority support',
      'Advanced security features',
      'Unlimited data retention',
      'Custom integrations',
      'Dedicated account manager',
      'SLA guarantee'
    ]
  },
  enterprise: {
    id: 'enterprise',
    name: 'Enterprise',
    price: 999,
    priceId: 'price_enterprise123',
    features: [
      'Everything in Professional, plus:',
      'Multi-region deployment',
      '24/7 premium support',
      'Custom SLA guarantees',
      'Advanced AI capabilities',
      'Dedicated infrastructure',
      'On-premise deployment option',
      'Custom compliance packages',
      'Unlimited team seats'
    ]
  }
} as const;

export type PlanTier = keyof typeof PRICING_TIERS;