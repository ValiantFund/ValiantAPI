export class CheckoutError extends Error {
  constructor(
    message: string,
    public code?: string,
    public details?: unknown
  ) {
    super(message);
    this.name = 'CheckoutError';
  }
}

export function handleCheckoutError(error: unknown): never {
  if (error instanceof CheckoutError) {
    throw error;
  }
  
  if (error instanceof Error) {
    throw new CheckoutError(error.message);
  }
  
  throw new CheckoutError('An unknown error occurred');
}