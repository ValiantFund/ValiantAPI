export interface CreateCheckoutSessionParams {
  priceId: string;
  userId: string;
  email: string;
}

export interface CheckoutSession {
  sessionId: string;
}

export interface CheckoutError {
  message: string;
  code?: string;
  details?: unknown;
}