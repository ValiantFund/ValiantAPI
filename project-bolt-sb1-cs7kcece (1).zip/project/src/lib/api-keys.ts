import { db } from './firebase';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';

// Generate a secure API key
function generateApiKey(prefix: 'live' | 'test'): string {
  const uuid = uuidv4().replace(/-/g, '');
  const timestamp = Date.now().toString(36);
  const randomBytes = Array.from(crypto.getRandomValues(new Uint8Array(8)))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
  return `${prefix}_${timestamp}${randomBytes}${uuid}`;
}

// Get user's API keys from Firestore
export async function getUserApiKeys(userId: string) {
  try {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      // Create initial API keys for new user
      const initialKeys = {
        production: generateApiKey('live'),
        test: generateApiKey('test'),
        productionUpdatedAt: new Date().toISOString(),
        testUpdatedAt: new Date().toISOString()
      };
      
      await setDoc(userRef, {
        apiKeys: initialKeys,
        createdAt: new Date().toISOString()
      }, { merge: true });
      
      return initialKeys;
    }
    
    const data = userDoc.data();
    if (!data.apiKeys) {
      // Create API keys if they don't exist
      const newKeys = {
        production: generateApiKey('live'),
        test: generateApiKey('test'),
        productionUpdatedAt: new Date().toISOString(),
        testUpdatedAt: new Date().toISOString()
      };
      
      await updateDoc(userRef, { apiKeys: newKeys });
      return newKeys;
    }
    
    return data.apiKeys;
  } catch (error) {
    console.error('Error fetching API keys:', error);
    throw new Error('Failed to fetch API keys');
  }
}

// Generate new API key
export async function regenerateApiKey(userId: string, keyType: 'production' | 'test') {
  try {
    const userRef = doc(db, 'users', userId);
    const newKey = generateApiKey(keyType === 'production' ? 'live' : 'test');
    
    const updates = {
      [`apiKeys.${keyType}`]: newKey,
      [`apiKeys.${keyType}UpdatedAt`]: new Date().toISOString()
    };
    
    await updateDoc(userRef, updates);
    return newKey;
  } catch (error) {
    console.error('Error regenerating API key:', error);
    throw new Error('Failed to generate new API key');
  }
}