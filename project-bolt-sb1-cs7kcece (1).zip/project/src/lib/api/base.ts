import { validateApiKey, validateIpWhitelist } from './security';
import { validateRequest, formatError, formatResponse } from './validation';
import type { z } from 'zod';

const API_BASE_URL = 'https://api.valiant.finance/v1';

export async function makeRequest<T>(
  apiKey: string,
  endpoint: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
  schema?: z.Schema<T>,
  data?: unknown,
  clientIp?: string
) {
  try {
    // Validate API key
    if (!validateApiKey(apiKey)) {
      return formatError('INVALID_API_KEY', 'Invalid or expired API key');
    }

    // Validate IP whitelist if client IP is provided
    if (clientIp) {
      const isValidIp = await validateIpWhitelist(apiKey.split('_')[1], clientIp);
      if (!isValidIp) {
        return formatError('UNAUTHORIZED_IP', 'IP address not whitelisted');
      }
    }

    // Validate request data if schema is provided
    if (schema && data) {
      const validation = validateRequest(schema)(data);
      if (!validation.success) {
        return formatError('VALIDATION_ERROR', 'Invalid request data', [validation.error]);
      }
      data = validation.data;
    }

    const headers = {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'X-Client-IP': clientIp || '',
    };

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method,
      headers,
      body: data ? JSON.stringify(data) : undefined,
    });

    if (!response.ok) {
      const error = await response.json();
      return formatError(
        error.code || 'API_ERROR',
        error.message || 'API request failed',
        error.details
      );
    }

    const result = await response.json();
    return formatResponse(result);
  } catch (error) {
    console.error('API request error:', error);
    return formatError(
      'NETWORK_ERROR',
      'Failed to complete the request',
      [(error as Error).message]
    );
  }
}