import { rateLimit } from 'express-rate-limit';
import { db } from '../firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';

// Rate limiting middleware
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later'
});

// IP Whitelist validation
export async function validateIpWhitelist(userId: string, ip: string): Promise<boolean> {
  try {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) return false;
    
    const { ipWhitelist = [] } = userDoc.data();
    return ipWhitelist.includes(ip) || ipWhitelist.length === 0;
  } catch (error) {
    console.error('Error validating IP whitelist:', error);
    return false;
  }
}

// Generate secure API key
export function generateSecureApiKey(prefix: 'live' | 'test'): string {
  const timestamp = Date.now().toString(36);
  const random = uuidv4().replace(/-/g, '');
  const key = `${prefix}_${timestamp}${random}`;
  return key;
}

// Validate API key format and expiration
export function validateApiKey(apiKey: string): boolean {
  if (!apiKey) return false;
  
  const [prefix, timestamp] = apiKey.split('_');
  if (!['live', 'test'].includes(prefix)) return false;
  
  // Check if key is expired (90 days)
  const keyTimestamp = parseInt(timestamp, 36);
  const expirationTime = 90 * 24 * 60 * 60 * 1000; // 90 days in milliseconds
  
  return Date.now() - keyTimestamp < expirationTime;
}

// Update API key
export async function rotateApiKey(userId: string, keyType: 'production' | 'test'): Promise<string> {
  try {
    const userRef = doc(db, 'users', userId);
    const newKey = generateSecureApiKey(keyType === 'production' ? 'live' : 'test');
    
    await updateDoc(userRef, {
      [`apiKeys.${keyType}`]: newKey,
      [`apiKeys.${keyType}UpdatedAt`]: new Date().toISOString()
    });
    
    return newKey;
  } catch (error) {
    console.error('Error rotating API key:', error);
    throw new Error('Failed to rotate API key');
  }
}