import { makeRequest } from './base';

export interface Account {
  id: string;
  type: 'business' | 'individual';
  currency: string;
  balance: number;
  status: 'active' | 'inactive' | 'frozen';
}

export interface CreateAccountParams {
  type: 'business' | 'individual';
  currency: string;
  businessName?: string;
  individualName?: string;
}

export function banking(apiKey: string) {
  return {
    createAccount: async (params: CreateAccountParams): Promise<Account> => {
      return makeRequest(apiKey, '/banking/accounts', 'POST', params);
    },

    getBalance: async (accountId: string) => {
      return makeRequest(apiKey, `/banking/accounts/${accountId}/balance`);
    },

    listTransactions: async (accountId: string) => {
      return makeRequest(apiKey, `/banking/accounts/${accountId}/transactions`);
    },
  };
}