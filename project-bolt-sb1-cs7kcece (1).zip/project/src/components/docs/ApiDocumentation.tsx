import React from 'react';
import { Code2, Shield, Zap, ArrowRight } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

const services = [
  {
    id: 'payments',
    title: 'Payments API',
    description: 'Process global payments and manage transactions',
    endpoints: [
      {
        name: 'Create Payment',
        method: 'POST',
        path: '/v1/payments',
        code: `// Process a payment
const payment = await valiant.payments.create({
  amount: 1000,    // Amount in cents
  currency: 'USD',
  description: 'Order #123',
  source: 'tok_visa'
});`,
        response: `{
  "id": "pay_123",
  "amount": 1000,
  "currency": "USD",
  "status": "succeeded",
  "created": "2024-02-20T12:00:00Z"
}`
      }
    ]
  },
  {
    id: 'lending',
    title: 'Lending API',
    description: 'Offer loans and credit products',
    endpoints: [
      {
        name: 'Create Loan Application',
        method: 'POST',
        path: '/v1/lending/applications',
        code: `// Create a loan application
const loan = await valiant.lending.create({
  amount: 50000,
  term: 12,        // months
  type: 'working_capital',
  businessId: 'bus_123'
});`,
        response: `{
  "id": "loan_123",
  "status": "pending",
  "amount": 50000,
  "term": 12,
  "interestRate": 6.5
}`
      }
    ]
  },
  {
    id: 'banking',
    title: 'Banking API',
    description: 'Virtual accounts and banking services',
    endpoints: [
      {
        name: 'Create Account',
        method: 'POST',
        path: '/v1/banking/accounts',
        code: `// Create a virtual account
const account = await valiant.banking.createAccount({
  type: 'business',
  currency: 'USD',
  businessName: 'Acme Inc'
});`,
        response: `{
  "id": "acct_123",
  "type": "business",
  "currency": "USD",
  "balance": 0,
  "status": "active"
}`
      }
    ]
  },
  {
    id: 'insurance',
    title: 'Insurance API',
    description: 'Embedded insurance products',
    endpoints: [
      {
        name: 'Get Quote',
        method: 'POST',
        path: '/v1/insurance/quotes',
        code: `// Get an insurance quote
const quote = await valiant.insurance.getQuote({
  type: 'product',
  coverage: 10000,
  productValue: 5000
});`,
        response: `{
  "id": "quote_123",
  "type": "product",
  "coverage": 10000,
  "premium": 250,
  "term": 12
}`
      }
    ]
  }
];

export function ApiDocumentation() {
  return (
    <div className="min-h-screen bg-gray-900 pt-24">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-white mb-6">
            API Documentation
          </h1>
          <p className="text-xl text-gray-400 mb-12">
            Comprehensive guide to integrating Valiant API services
          </p>

          {/* Authentication */}
          <section className="bg-gray-800 rounded-xl p-8 mb-8">
            <div className="flex items-center mb-6">
              <Shield className="w-8 h-8 text-purple-400 mr-4" />
              <h2 className="text-2xl font-semibold text-white">Authentication</h2>
            </div>
            <p className="text-gray-300 mb-6">
              All API requests require authentication using your API key. Include it in the Authorization header:
            </p>
            <SyntaxHighlighter
              language="javascript"
              style={vscDarkPlus}
              className="rounded-lg"
            >
{`// Initialize the client
const valiant = new ValiantAPI('your_api_key');

// Or using fetch directly
fetch('https://api.valiant.finance/v1/payments', {
  headers: {
    'Authorization': 'Bearer your_api_key',
    'Content-Type': 'application/json'
  }
});`}
            </SyntaxHighlighter>
          </section>

          {/* Services */}
          {services.map((service) => (
            <section key={service.id} className="bg-gray-800 rounded-xl p-8 mb-8">
              <div className="flex items-center mb-6">
                <Zap className="w-8 h-8 text-purple-400 mr-4" />
                <div>
                  <h2 className="text-2xl font-semibold text-white">{service.title}</h2>
                  <p className="text-gray-400 mt-1">{service.description}</p>
                </div>
              </div>

              {service.endpoints.map((endpoint, index) => (
                <div key={index} className="mb-8 last:mb-0">
                  <div className="flex items-center space-x-3 mb-4">
                    <span className="bg-purple-500/20 text-purple-400 px-3 py-1 rounded-lg text-sm font-medium">
                      {endpoint.method}
                    </span>
                    <code className="text-gray-300 font-mono">{endpoint.path}</code>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-white font-medium mb-2">Request</h4>
                      <SyntaxHighlighter
                        language="javascript"
                        style={vscDarkPlus}
                        className="rounded-lg"
                      >
                        {endpoint.code}
                      </SyntaxHighlighter>
                    </div>

                    <div>
                      <h4 className="text-white font-medium mb-2">Response</h4>
                      <SyntaxHighlighter
                        language="json"
                        style={vscDarkPlus}
                        className="rounded-lg"
                      >
                        {endpoint.response}
                      </SyntaxHighlighter>
                    </div>
                  </div>
                </div>
              ))}
            </section>
          ))}

          {/* Error Handling */}
          <section className="bg-gray-800 rounded-xl p-8 mb-8">
            <div className="flex items-center mb-6">
              <Code2 className="w-8 h-8 text-purple-400 mr-4" />
              <h2 className="text-2xl font-semibold text-white">Error Handling</h2>
            </div>
            <p className="text-gray-300 mb-6">
              Handle API errors gracefully using try-catch blocks:
            </p>
            <SyntaxHighlighter
              language="javascript"
              style={vscDarkPlus}
              className="rounded-lg"
            >
{`try {
  const payment = await valiant.payments.create({
    amount: 1000,
    currency: 'USD'
  });
} catch (error) {
  if (error.code === 'insufficient_funds') {
    // Handle insufficient funds error
  } else if (error.code === 'card_declined') {
    // Handle declined card error
  } else {
    // Handle other errors
  }
}`}
            </SyntaxHighlighter>
          </section>

          {/* Get Started */}
          <div className="bg-purple-600 rounded-xl p-8">
            <h2 className="text-2xl font-semibold text-white mb-4">Ready to Start Building?</h2>
            <p className="text-purple-100 mb-6">
              Get your API keys and start integrating financial services into your platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="inline-flex items-center justify-center space-x-2 bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                <span>Get API Keys</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button className="inline-flex items-center justify-center space-x-2 bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-800 transition-colors">
                <span>View Examples</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}