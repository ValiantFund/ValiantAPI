import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

export function GetStarted() {
  const steps = [
    {
      title: 'Create an Account',
      description: 'Sign up for a Valiant API account to get your API keys and access the dashboard.',
      action: 'Sign Up Now',
      link: '/signup'
    },
    {
      title: 'Choose Your Services',
      description: 'Select the financial services you want to integrate: Payments, Lending, Banking, Insurance, or Compliance.',
      action: 'View Services',
      link: '/#products'
    },
    {
      title: 'Install SDK',
      description: 'Install our SDK using npm, yarn, or pnpm:',
      code: 'npm install @valiant/api'
    },
    {
      title: 'Initialize the Client',
      description: 'Initialize the Valiant API client with your API key:',
      code: `import { ValiantAPI } from '@valiant/api';

const valiant = new ValiantAPI('your_api_key');`
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-24">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-white mb-6">
            Get Started with Valiant API
          </h1>
          <p className="text-xl text-gray-400 mb-12">
            Follow these simple steps to integrate financial services into your platform.
          </p>

          <div className="space-y-12">
            {steps.map((step, index) => (
              <div key={index} className="bg-gray-800 rounded-xl p-8">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 rounded-full bg-purple-500 flex items-center justify-center text-white font-semibold">
                    {index + 1}
                  </div>
                  <h2 className="text-2xl font-semibold text-white ml-4">{step.title}</h2>
                </div>
                <p className="text-gray-300 mb-6">{step.description}</p>
                {step.code && (
                  <pre className="bg-gray-900 p-4 rounded-lg mb-6 overflow-x-auto">
                    <code className="text-gray-300 font-mono">{step.code}</code>
                  </pre>
                )}
                {step.action && (
                  <Link
                    to={step.link}
                    className="inline-flex items-center space-x-2 bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg transition-colors"
                  >
                    <span>{step.action}</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                )}
              </div>
            ))}
          </div>

          <div className="bg-purple-600 rounded-xl p-8 mt-12">
            <h2 className="text-2xl font-semibold text-white mb-4">Ready to Build?</h2>
            <p className="text-purple-100 mb-6">
              Create your account now and start integrating financial services into your platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/signup"
                className="inline-flex items-center justify-center space-x-2 bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                <span>Create Account</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/dashboard/docs"
                className="inline-flex items-center justify-center space-x-2 bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-800 transition-colors"
              >
                <span>View Documentation</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}