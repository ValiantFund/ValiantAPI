import React from 'react';
import { Code2, Shield, Zap, ArrowRight } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

const codeExamples = {
  payments: `// Initialize the Valiant API client
const valiant = new ValiantAPI('YOUR_API_KEY');

// Process a payment
const payment = await valiant.payments.create({
  amount: 1000, // Amount in cents
  currency: 'USD',
  description: 'Payment for order #123'
});`,

  lending: `// Initialize lending service
const loan = await valiant.lending.create({
  amount: 50000,
  term: 12, // months
  type: 'working_capital',
  businessId: 'bus_123'
});

// Check loan status
const status = await valiant.lending.getStatus(loan.id);`,

  banking: `// Create a virtual account
const account = await valiant.banking.createAccount({
  type: 'business',
  currency: 'USD',
  businessName: 'Acme Inc'
});

// Get account balance
const balance = await valiant.banking.getBalance(account.id);`,

  insurance: `// Get insurance quote
const quote = await valiant.insurance.getQuote({
  type: 'product',
  coverage: 10000,
  productValue: 5000
});

// Create policy
const policy = await valiant.insurance.createPolicy(quote.id);`,

  compliance: `// Verify business identity
const verification = await valiant.compliance.verify({
  type: 'business',
  data: {
    name: 'Acme Inc',
    taxId: '123456789',
    address: {
      country: 'US',
      state: 'CA'
    }
  }
});`
};

export function ApiIntegrationGuide() {
  return (
    <div className="min-h-screen bg-gray-900 pt-24">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-white mb-6">
            API Integration Guide
          </h1>
          <p className="text-xl text-gray-400 mb-12">
            Learn how to integrate Valiant API's financial services into your application
          </p>

          <div className="space-y-12">
            {/* Authentication */}
            <section className="bg-gray-800 rounded-xl p-8">
              <div className="flex items-center mb-6">
                <Shield className="w-8 h-8 text-purple-400 mr-4" />
                <h2 className="text-2xl font-semibold text-white">Authentication</h2>
              </div>
              <p className="text-gray-300 mb-6">
                All API requests must include your API key in the Authorization header:
              </p>
              <SyntaxHighlighter
                language="javascript"
                style={vscDarkPlus}
                className="rounded-lg mb-4"
              >
                {`// Using fetch
const response = await fetch('https://api.valiant.finance/v1/payments', {
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  }
});`}
              </SyntaxHighlighter>
              <div className="bg-gray-900 p-4 rounded-lg">
                <p className="text-gray-300 text-sm">
                  🔑 Use your test API key for development and testing. Switch to your production API key when you're ready to go live.
                </p>
              </div>
            </section>

            {/* Services */}
            <section className="bg-gray-800 rounded-xl p-8">
              <div className="flex items-center mb-6">
                <Zap className="w-8 h-8 text-purple-400 mr-4" />
                <h2 className="text-2xl font-semibold text-white">Available Services</h2>
              </div>
              
              {/* Payments */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-white mb-4">Payments API</h3>
                <p className="text-gray-300 mb-4">
                  Process payments, handle refunds, and manage subscriptions:
                </p>
                <SyntaxHighlighter
                  language="javascript"
                  style={vscDarkPlus}
                  className="rounded-lg"
                >
                  {codeExamples.payments}
                </SyntaxHighlighter>
              </div>

              {/* Lending */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-white mb-4">Lending API</h3>
                <p className="text-gray-300 mb-4">
                  Offer loans and credit products to your customers:
                </p>
                <SyntaxHighlighter
                  language="javascript"
                  style={vscDarkPlus}
                  className="rounded-lg"
                >
                  {codeExamples.lending}
                </SyntaxHighlighter>
              </div>

              {/* Banking */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-white mb-4">Banking API</h3>
                <p className="text-gray-300 mb-4">
                  Create virtual accounts and manage transactions:
                </p>
                <SyntaxHighlighter
                  language="javascript"
                  style={vscDarkPlus}
                  className="rounded-lg"
                >
                  {codeExamples.banking}
                </SyntaxHighlighter>
              </div>

              {/* Insurance */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-white mb-4">Insurance API</h3>
                <p className="text-gray-300 mb-4">
                  Offer insurance products and manage policies:
                </p>
                <SyntaxHighlighter
                  language="javascript"
                  style={vscDarkPlus}
                  className="rounded-lg"
                >
                  {codeExamples.insurance}
                </SyntaxHighlighter>
              </div>

              {/* Compliance */}
              <div>
                <h3 className="text-xl font-semibold text-white mb-4">Compliance API</h3>
                <p className="text-gray-300 mb-4">
                  Handle KYC, AML, and regulatory requirements:
                </p>
                <SyntaxHighlighter
                  language="javascript"
                  style={vscDarkPlus}
                  className="rounded-lg"
                >
                  {codeExamples.compliance}
                </SyntaxHighlighter>
              </div>
            </section>

            {/* Best Practices */}
            <section className="bg-gray-800 rounded-xl p-8">
              <div className="flex items-center mb-6">
                <Code2 className="w-8 h-8 text-purple-400 mr-4" />
                <h2 className="text-2xl font-semibold text-white">Best Practices</h2>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
                  <span className="text-gray-300">Always use environment variables to store API keys</span>
                </li>
                <li className="flex items-start">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
                  <span className="text-gray-300">Implement proper error handling for API responses</span>
                </li>
                <li className="flex items-start">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
                  <span className="text-gray-300">Use webhooks for real-time updates on transactions and events</span>
                </li>
                <li className="flex items-start">
                  <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
                  <span className="text-gray-300">Test thoroughly in sandbox environment before going live</span>
                </li>
              </ul>
            </section>

            {/* Next Steps */}
            <div className="bg-purple-600 rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-white mb-4">Ready to Start Building?</h2>
              <p className="text-purple-100 mb-6">
                Get your API keys and start integrating financial services into your platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="inline-flex items-center justify-center space-x-2 bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                  <span>Get API Keys</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button className="inline-flex items-center justify-center space-x-2 bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-800 transition-colors">
                  <span>View Full Documentation</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}