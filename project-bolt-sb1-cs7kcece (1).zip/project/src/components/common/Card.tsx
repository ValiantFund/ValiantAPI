import React from 'react';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
}

export function Card({ title, children, className = '' }: CardProps) {
  return (
    <div className={`bg-gray-800 rounded-xl p-6 ${className}`}>
      {title && (
        <h3 className="text-xl font-semibold text-white mb-4">{title}</h3>
      )}
      {children}
    </div>
  );
}