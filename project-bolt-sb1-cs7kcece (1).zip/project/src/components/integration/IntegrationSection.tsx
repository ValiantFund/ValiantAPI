import React from 'react';
import { IntegrationButtons } from './IntegrationButtons';

export function IntegrationSection() {
  return (
    <section id="integrations" className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Integration Tools
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Connect Valiant API with your favorite platforms
          </p>
        </div>
        <IntegrationButtons />
      </div>
    </section>
  );
}