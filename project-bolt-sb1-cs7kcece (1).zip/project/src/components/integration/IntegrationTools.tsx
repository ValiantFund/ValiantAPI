import React from 'react';
import { Link } from 'react-router-dom';
import { Code2, Puzzle, Blocks } from 'lucide-react';
import { INTEGRATION_GUIDES } from './integrationData';

export function IntegrationTools() {
  return (
    <div className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Integration Tools
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Multiple ways to integrate Valiant API into your platform
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {Object.entries(INTEGRATION_GUIDES).map(([key, guide]) => (
            <Link
              key={key}
              to={`/integration/${key}`}
              className="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition-colors border border-gray-700 hover:border-purple-500"
            >
              <div className="flex items-center space-x-4 mb-4">
                <div className="bg-purple-500/10 p-3 rounded-lg">
                  {guide.icon}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">
                    {guide.title}
                  </h3>
                  <p className="text-sm text-gray-400">
                    {guide.description}
                  </p>
                </div>
              </div>
              <div className="flex items-center text-purple-400 text-sm">
                <span>View Integration Guide</span>
                <Code2 className="w-4 h-4 ml-2" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}