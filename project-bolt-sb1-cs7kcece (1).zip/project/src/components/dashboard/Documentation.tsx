import React from 'react';
import { Editor } from '@monaco-editor/react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/Tabs';

const installationCode = `# Using npm
npm install @valiant/api

# Using yarn
yarn add @valiant/api

# Using pnpm
pnpm add @valiant/api`;

const initializationCode = `import { ValiantAPI } from '@valiant/api';

// Initialize the client with your API key
const valiant = new ValiantAPI('your_api_key');`;

const servicesExamples = {
  payments: `// Process a payment
const payment = await valiant.payments.create({
  amount: 1000, // Amount in cents
  currency: 'USD',
  description: 'Payment for order #123',
  source: 'tok_visa' // Token from payment form
});

// Retrieve payment details
const paymentDetails = await valiant.payments.retrieve(payment.id);

// List payments
const payments = await valiant.payments.list({ limit: 10 });`,

  lending: `// Create a loan application
const loan = await valiant.lending.create({
  amount: 50000,
  term: 12, // months
  type: 'working_capital',
  businessId: 'bus_123'
});

// Check loan application status
const decision = await valiant.lending.getDecision(loan.id);`,

  banking: `// Create a virtual account
const account = await valiant.banking.createAccount({
  type: 'business',
  currency: 'USD',
  businessName: 'Acme Inc'
});

// Get account balance
const balance = await valiant.banking.getBalance(account.id);

// List transactions
const transactions = await valiant.banking.listTransactions(account.id);`,

  insurance: `// Get an insurance quote
const quote = await valiant.insurance.getQuote({
  type: 'product',
  coverage: 10000,
  duration: 12
});

// Create an insurance policy
const policy = await valiant.insurance.createPolicy({
  type: 'product',
  coverage: quote.coverage,
  duration: quote.duration
});`,

  compliance: `// Verify a business
const verification = await valiant.compliance.verify({
  type: 'business',
  data: {
    name: 'Acme Inc',
    taxId: '123456789',
    address: {
      street: '123 Main St',
      city: 'San Francisco',
      country: 'US',
      postalCode: '94105'
    }
  }
});

// Check verification status
const status = await valiant.compliance.checkStatus(verification.id);`
};

const errorHandlingCode = `try {
  const payment = await valiant.payments.create({
    amount: 1000,
    currency: 'USD'
  });
} catch (error) {
  if (error.code === 'insufficient_funds') {
    // Handle insufficient funds error
  } else if (error.code === 'card_declined') {
    // Handle declined card error
  } else {
    // Handle other errors
  }
}`;

export function Documentation() {
  return (
    <div className="space-y-8">
      <div className="border-b border-gray-700 pb-8">
        <h1 className="text-3xl font-bold text-white mb-4">Getting Started with ValiantAPI</h1>
        <p className="text-gray-300">
          Follow this guide to integrate ValiantAPI's financial services into your application.
        </p>
      </div>

      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-white">Installation</h2>
        <div className="bg-gray-800 rounded-xl p-6">
          <SyntaxHighlighter language="bash" style={vscDarkPlus}>
            {installationCode}
          </SyntaxHighlighter>
        </div>
      </section>

      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-white">Initialization</h2>
        <div className="bg-gray-800 rounded-xl p-6">
          <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
            {initializationCode}
          </SyntaxHighlighter>
        </div>
      </section>

      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-white">Services Integration</h2>
        <div className="bg-gray-800 rounded-xl p-6">
          <Tabs defaultValue="payments">
            <TabsList className="border-b border-gray-700 mb-6">
              <TabsTrigger value="payments">Payments</TabsTrigger>
              <TabsTrigger value="lending">Lending</TabsTrigger>
              <TabsTrigger value="banking">Banking</TabsTrigger>
              <TabsTrigger value="insurance">Insurance</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
            </TabsList>
            <TabsContent value="payments">
              <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
                {servicesExamples.payments}
              </SyntaxHighlighter>
            </TabsContent>
            <TabsContent value="lending">
              <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
                {servicesExamples.lending}
              </SyntaxHighlighter>
            </TabsContent>
            <TabsContent value="banking">
              <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
                {servicesExamples.banking}
              </SyntaxHighlighter>
            </TabsContent>
            <TabsContent value="insurance">
              <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
                {servicesExamples.insurance}
              </SyntaxHighlighter>
            </TabsContent>
            <TabsContent value="compliance">
              <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
                {servicesExamples.compliance}
              </SyntaxHighlighter>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-white">Error Handling</h2>
        <div className="bg-gray-800 rounded-xl p-6">
          <SyntaxHighlighter language="javascript" style={vscDarkPlus}>
            {errorHandlingCode}
          </SyntaxHighlighter>
        </div>
      </section>

      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-white">Interactive Playground</h2>
        <div className="bg-gray-800 rounded-xl p-6">
          <div className="h-[400px]">
            <Editor
              height="100%"
              defaultLanguage="javascript"
              defaultValue={servicesExamples.payments}
              theme="vs-dark"
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                readOnly: false
              }}
            />
          </div>
        </div>
      </section>

      <section className="bg-gray-800 rounded-xl p-6 mt-8">
        <h2 className="text-xl font-semibold text-white mb-4">Next Steps</h2>
        <ul className="space-y-3 text-gray-300">
          <li className="flex items-start">
            <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
            <span>Review our comprehensive API reference documentation</span>
          </li>
          <li className="flex items-start">
            <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
            <span>Join our developer community for support and updates</span>
          </li>
          <li className="flex items-start">
            <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
            <span>Set up webhooks to receive real-time event notifications</span>
          </li>
          <li className="flex items-start">
            <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2 mt-2" />
            <span>Explore our sample applications and integration guides</span>
          </li>
        </ul>
      </section>
    </div>
  );
}