import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { Card } from '../common/Card';
import { useApiLimits } from '../../hooks/useApiLimits';
import { usePlan } from '../../hooks/usePlan';
import { Button } from '../common/Button';
import { Link } from 'react-router-dom';

export function UsageLimits() {
  const { usage, remainingCalls, usagePercentage, loading, isOverLimit } = useApiLimits();
  const { currentPlan } = usePlan();

  if (loading) {
    return <Card>Loading usage data...</Card>;
  }

  if (currentPlan !== 'free') {
    return null;
  }

  return (
    <Card className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">API Usage</h3>
        {isOverLimit && (
          <span className="flex items-center text-red-400">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Usage limit reached
          </span>
        )}
      </div>

      <div className="mb-4">
        <div className="flex justify-between text-sm text-gray-400 mb-2">
          <span>{usage.calls.toLocaleString()} calls used</span>
          <span>{remainingCalls.toLocaleString()} remaining</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2">
          <div
            className={`h-full rounded-full ${
              usagePercentage > 90 ? 'bg-red-500' : 'bg-purple-500'
            }`}
            style={{ width: `${Math.min(usagePercentage, 100)}%` }}
          />
        </div>
      </div>

      {(usagePercentage > 80 || isOverLimit) && (
        <div className="text-center">
          <Link to="/pricing">
            <Button variant="primary" size="sm">
              Upgrade Plan
            </Button>
          </Link>
        </div>
      )}
    </Card>
  );
}