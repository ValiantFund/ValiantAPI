import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { PRICING_PLANS, PlanId } from '../../../config/pricing';
import { Button } from '../../ui/Button';
import { Dialog } from '../../ui/Dialog';
import { PlanCard } from './PlanCard';
import { useCheckout } from '../../../hooks/useCheckout';
import { STRIPE_PRICE_IDS } from '../../../lib/stripe';

interface PlanUpgradeProps {
  currentPlan: PlanId;
}

export function PlanUpgrade({ currentPlan }: PlanUpgradeProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { startCheckout, loading, error } = useCheckout();

  const handlePlanSelect = async (planId: PlanId) => {
    try {
      const priceId = STRIPE_PRICE_IDS[planId];
      await startCheckout(priceId);
      setIsOpen(false);
    } catch (err) {
      console.error('Failed to start checkout:', err);
    }
  };

  return (
    <>
      <Button 
        onClick={() => setIsOpen(true)}
        variant="primary"
        className="flex items-center space-x-2"
      >
        <span>Upgrade Plan</span>
        <ArrowRight className="w-4 h-4" />
      </Button>

      <Dialog
        open={isOpen}
        onOpenChange={setIsOpen}
        title="Choose Your Plan"
        description="Select the plan that best fits your needs"
      >
        <div className="grid gap-6 mt-4">
          {Object.entries(PRICING_PLANS).map(([id, plan]) => (
            <PlanCard
              key={id}
              plan={plan}
              isCurrentPlan={id === currentPlan}
              onSelect={() => handlePlanSelect(id as PlanId)}
              loading={loading}
            />
          ))}
        </div>
        {error && (
          <p className="mt-4 text-red-400 text-sm">{error}</p>
        )}
      </Dialog>
    </>
  );
}