import React from 'react';
import { CreditCard, DollarSign, AlertTriangle } from 'lucide-react';
import { usePlan } from '../../../hooks/usePlan';
import { PRICING_PLANS } from '../../../config/pricing';
import { PlanUsage } from './PlanUsage';
import { PlanUpgrade } from './PlanUpgrade';
import { PaymentMethod } from './PaymentMethod';
import { BillingHistory } from './BillingHistory';

export function BillingOverview() {
  const { currentPlan, loading, error } = usePlan();

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-gray-400">Loading billing information...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-6 max-w-md text-center">
          <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">Failed to Load Billing</h3>
          <p className="text-gray-400 mb-4">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="text-red-400 hover:text-red-300 text-sm"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  const plan = PRICING_PLANS[currentPlan];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Billing & Subscription</h1>
          <p className="text-gray-400 mt-1">Manage your plan and payment details</p>
        </div>
        <PlanUpgrade currentPlan={currentPlan} />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold text-white mb-4">Current Plan</h2>
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-purple-400 font-semibold text-lg">
                {plan.name} Plan
              </p>
              <p className="text-2xl font-bold text-white">
                ${plan.basePrice}
                <span className="text-gray-400 text-sm font-normal">/month</span>
              </p>
            </div>
            <p className="text-gray-400 text-sm">
              Billing period: Monthly • Next invoice on March 1, 2024
            </p>
          </div>
          <PlanUsage plan={plan} />
        </div>

        <PaymentMethod />
      </div>

      <BillingHistory />
    </div>
  );
}