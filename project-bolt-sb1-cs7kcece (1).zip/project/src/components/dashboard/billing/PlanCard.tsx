import React from 'react';
import { Check, Loader2 } from 'lucide-react';
import { Button } from '../../ui/Button';
import type { PricingPlan } from '../../../config/pricing';

interface PlanCardProps {
  plan: PricingPlan;
  isCurrentPlan: boolean;
  onSelect: () => void;
  loading?: boolean;
}

export function PlanCard({ plan, isCurrentPlan, onSelect, loading }: PlanCardProps) {
  return (
    <div className={`bg-gray-800 rounded-xl p-6 border-2 ${
      isCurrentPlan ? 'border-purple-500' : 'border-gray-700'
    }`}>
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-semibold text-white">{plan.name}</h3>
          <div className="mt-2">
            <span className="text-3xl font-bold text-white">${plan.basePrice}</span>
            <span className="text-gray-400">/month</span>
          </div>
        </div>
        {isCurrentPlan && (
          <span className="bg-purple-500/10 text-purple-400 px-3 py-1 rounded-full text-sm">
            Current Plan
          </span>
        )}
      </div>

      <ul className="space-y-3 mb-6">
        {plan.features.map((feature, index) => (
          <li key={index} className="flex items-start text-gray-300">
            <Check className="w-5 h-5 text-purple-400 mr-2 flex-shrink-0" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>

      <Button
        variant={isCurrentPlan ? 'secondary' : 'primary'}
        className="w-full"
        disabled={isCurrentPlan || loading}
        onClick={onSelect}
        loading={loading}
      >
        {isCurrentPlan ? 'Current Plan' : 'Upgrade to ' + plan.name}
      </Button>
    </div>
  );
}