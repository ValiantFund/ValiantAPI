import React from 'react';
import { CreditCard } from 'lucide-react';
import { Button } from '../../ui/Button';

export function PaymentMethod() {
  return (
    <div className="bg-gray-800 rounded-xl p-6">
      <h2 className="text-xl font-semibold text-white mb-4">Payment Method</h2>
      <div className="flex items-center space-x-4">
        <div className="bg-gray-700 p-3 rounded-lg">
          <CreditCard className="w-6 h-6 text-gray-400" />
        </div>
        <div>
          <p className="text-white">•••• •••• •••• 4242</p>
          <p className="text-gray-400 text-sm">Expires 12/25</p>
        </div>
        <Button variant="outline" className="ml-auto">
          Update
        </Button>
      </div>
    </div>
  );
}