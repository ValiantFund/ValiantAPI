import React from 'react';
import { DollarSign } from 'lucide-react';

export function BillingHistory() {
  const transactions = [
    { date: 'February 2024', amount: 199.00 },
    { date: 'January 2024', amount: 199.00 },
    { date: 'December 2023', amount: 199.00 }
  ];

  return (
    <div className="bg-gray-800 rounded-xl p-6">
      <h2 className="text-xl font-semibold text-white mb-4">Billing History</h2>
      <div className="space-y-4">
        {transactions.map((transaction, index) => (
          <div key={index} className="flex items-center justify-between text-gray-300">
            <div className="flex items-center space-x-3">
              <DollarSign className="w-5 h-5 text-gray-400" />
              <span>{transaction.date}</span>
            </div>
            <span>${transaction.amount.toFixed(2)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}