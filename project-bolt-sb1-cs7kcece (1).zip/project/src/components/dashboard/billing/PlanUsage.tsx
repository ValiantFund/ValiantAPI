import React from 'react';
import { Progress } from '../../ui/Progress';

interface PlanUsageProps {
  plan: {
    apiCalls: {
      included: number;
    };
    transactionFees: {
      included: number;
    };
  };
}

export function PlanUsage({ plan }: PlanUsageProps) {
  const apiUsage = 5432; // This would come from your usage tracking
  const apiUsagePercent = (apiUsage / plan.apiCalls.included) * 100;
  
  const transactionVolume = 50000;
  const volumePercent = (transactionVolume / plan.transactionFees.included) * 100;

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-gray-300">API calls used this month</span>
          <span className="text-gray-300">
            {apiUsage.toLocaleString()} / {plan.apiCalls.included.toLocaleString()}
          </span>
        </div>
        <Progress value={apiUsagePercent} />
      </div>

      <div>
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-gray-300">Transaction volume</span>
          <span className="text-gray-300">
            ${transactionVolume.toLocaleString()} / ${plan.transactionFees.included.toLocaleString()}
          </span>
        </div>
        <Progress value={volumePercent} />
      </div>
    </div>
  );
}