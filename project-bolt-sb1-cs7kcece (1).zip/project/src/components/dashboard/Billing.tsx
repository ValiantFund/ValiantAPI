import React from 'react';
import { BillingOverview } from './billing/BillingOverview';

export function Billing() {
  return <BillingOverview />;
}