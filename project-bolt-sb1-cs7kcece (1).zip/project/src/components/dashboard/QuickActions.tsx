import React from 'react';
import { Link } from 'react-router-dom';
import { Code, Zap, LineChart, DollarSign } from 'lucide-react';

const actions = [
  {
    title: 'API Keys',
    description: 'Manage access',
    icon: <Code />,
    path: '/dashboard/api-keys'
  },
  {
    title: 'Documentation',
    description: 'Learn & build',
    icon: <Zap />,
    path: '/dashboard/docs'
  },
  {
    title: 'Analytics',
    description: 'View insights',
    icon: <LineChart />,
    path: '/dashboard/analytics'
  },
  {
    title: 'Billing',
    description: 'Manage plan',
    icon: <DollarSign />,
    path: '/dashboard/billing'
  }
];

export function QuickActions() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {actions.map((action) => (
        <Link
          key={action.title}
          to={action.path}
          className="bg-gray-800 p-6 rounded-xl hover:bg-gray-750 transition-colors group"
        >
          <div className="flex items-center space-x-4">
            <div className="bg-purple-500/10 p-3 rounded-lg group-hover:bg-purple-500/20 transition-colors">
              {React.cloneElement(action.icon, { className: "w-6 h-6 text-purple-400" })}
            </div>
            <div>
              <h3 className="text-white font-semibold">{action.title}</h3>
              <p className="text-gray-400 text-sm">{action.description}</p>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}