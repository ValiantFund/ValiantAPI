import React from 'react';
import { CreditCard, DollarSign, Building2, Shield, ArrowRight } from 'lucide-react';

const examples = [
  {
    title: "Payments Integration",
    description: "Seamless payment processing interface",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&w=800&q=80",
    features: [
      "Global payment processing",
      "Multi-currency support",
      "Secure checkout flow",
      "Real-time monitoring"
    ],
    mockup: {
      type: "dashboard",
      content: (
        <div className="w-full bg-gray-800/90 backdrop-blur-sm rounded-lg p-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-gray-900/80 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-400">$1.2M</div>
              <div className="text-sm text-gray-400">Today's Volume</div>
              <div className="text-xs text-green-400 mt-1">↑ 12.5%</div>
            </div>
            <div className="bg-gray-900/80 p-4 rounded-lg">
              <div className="text-2xl font-bold text-purple-400">99.9%</div>
              <div className="text-sm text-gray-400">Success Rate</div>
              <div className="text-xs text-purple-400 mt-1">↑ 0.2%</div>
            </div>
            <div className="bg-gray-900/80 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-400">45ms</div>
              <div className="text-sm text-gray-400">Avg. Response</div>
              <div className="text-xs text-blue-400 mt-1">↓ 5ms</div>
            </div>
          </div>
        </div>
      )
    }
  },
  {
    title: "Lending Platform",
    description: "AI-powered lending and credit decisions",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=800&q=80",
    features: [
      "Automated underwriting",
      "Risk assessment",
      "Loan management",
      "Payment tracking"
    ],
    mockup: {
      type: "application",
      content: (
        <div className="w-full bg-gray-800/90 backdrop-blur-sm rounded-lg p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-400">Loan Amount</div>
                <div className="text-2xl font-bold text-white">$50,000</div>
              </div>
              <div className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-sm">
                Approved
              </div>
            </div>
            <div className="bg-gray-900/50 h-2 rounded-full overflow-hidden">
              <div className="bg-purple-500 h-full w-3/4"></div>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-gray-400 text-sm">Term</div>
                <div className="text-white font-bold">12 mo</div>
              </div>
              <div>
                <div className="text-gray-400 text-sm">Rate</div>
                <div className="text-white font-bold">6.5%</div>
              </div>
              <div>
                <div className="text-gray-400 text-sm">Monthly</div>
                <div className="text-white font-bold">$4,375</div>
              </div>
            </div>
          </div>
        </div>
      )
    }
  },
  {
    title: "Banking Services",
    description: "Virtual account and transaction management",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80",
    features: [
      "Account creation",
      "Balance monitoring",
      "Transaction history",
      "Fund transfers"
    ],
    mockup: {
      type: "mobile",
      content: (
        <div className="w-4/5 mx-auto bg-gray-800/90 backdrop-blur-sm rounded-lg p-6">
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-gray-400 text-sm">Available Balance</div>
              <div className="text-3xl font-bold text-white">$24,150.75</div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-purple-500/20 p-3 rounded-lg text-center">
                <div className="text-purple-400 text-sm">Send</div>
              </div>
              <div className="bg-purple-500/20 p-3 rounded-lg text-center">
                <div className="text-purple-400 text-sm">Request</div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="bg-gray-900/50 p-2 rounded-lg flex justify-between">
                <span className="text-gray-300">Netflix</span>
                <span className="text-red-400">-$14.99</span>
              </div>
              <div className="bg-gray-900/50 p-2 rounded-lg flex justify-between">
                <span className="text-gray-300">Salary</span>
                <span className="text-green-400">+$5,250.00</span>
              </div>
            </div>
          </div>
        </div>
      )
    }
  },
  {
    title: "Compliance Suite",
    description: "Automated KYC and regulatory compliance",
    image: "https://images.unsplash.com/photo-1576224663326-0e3d3e1fd729?auto=format&fit=crop&w=800&q=80",
    features: [
      "Identity verification",
      "Document processing",
      "Risk monitoring",
      "Compliance reporting"
    ],
    mockup: {
      type: "workflow",
      content: (
        <div className="w-full bg-gray-800/90 backdrop-blur-sm rounded-lg p-6">
          <div className="flex justify-between items-center">
            {['Verification', 'Analysis', 'Review', 'Approval'].map((stage, idx) => (
              <div key={idx} className="flex flex-col items-center">
                <div className={`w-4 h-4 rounded-full ${
                  idx === 0 ? 'bg-green-500' :
                  idx === 1 ? 'bg-purple-500' :
                  'bg-gray-600'
                } ${idx < 2 ? 'ring-4 ring-green-500/20' : ''}`} />
                <div className="h-0.5 w-16 bg-gray-700 absolute" />
                <div className="text-gray-300 text-sm mt-6">{stage}</div>
                {idx < 2 && (
                  <div className="text-xs text-green-400 mt-1">Completed</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )
    }
  }
];

export function ProductExamples() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Integration Examples
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Transform your platform with our embedded financial services
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {examples.map((example, index) => (
            <div key={index} className="bg-gray-800 rounded-xl overflow-hidden group hover:ring-2 hover:ring-purple-500 transition-all">
              <div className="h-64 relative">
                <img
                  src={example.image}
                  alt={example.title}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/60 to-transparent" />
                
                {/* Mockup Interface */}
                <div className="absolute inset-0 flex items-center justify-center p-6">
                  {example.mockup.content}
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-2xl font-semibold text-white mb-3">
                  {example.title}
                </h3>
                <p className="text-gray-400 mb-4">{example.description}</p>
                <ul className="space-y-2">
                  {example.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-300">
                      <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="inline-flex items-center space-x-2 bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-lg transition-colors">
            <span>Start Building</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}