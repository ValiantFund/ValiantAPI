import React from 'react';
import { Check, X } from 'lucide-react';
import { PRICING_TIERS, PlanTier, FREE_TRIAL_DURATION } from '../../config/plans';
import { Button } from '../common/Button';
import { useAuth } from '../../hooks/useAuth';
import { usePlan } from '../../hooks/usePlan';
import { useNavigate } from 'react-router-dom';

export function FreemiumPricing() {
  const { user } = useAuth();
  const { currentPlan } = usePlan();
  const navigate = useNavigate();

  const handlePlanSelect = (planId: PlanTier) => {
    if (!user) {
      navigate('/signup');
      return;
    }

    if (planId === 'free') {
      navigate('/dashboard');
      return;
    }

    navigate(`/checkout/${planId}`);
  };

  return (
    <div className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-gray-400 mb-2">
            Start for free, upgrade as you grow
          </p>
          <p className="text-purple-400 text-lg">
            Try any paid plan free for {FREE_TRIAL_DURATION} days
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {Object.entries(PRICING_TIERS).map(([id, plan]) => {
            const isCurrentPlan = currentPlan === id;
            const isPro = plan.name === 'Professional';
            
            return (
              <div
                key={id}
                className={`bg-gray-800 rounded-xl p-8 border-2 ${
                  isPro ? 'border-purple-500' : 'border-gray-700'
                } ${isPro ? 'lg:scale-105' : ''}`}
              >
                {isPro && (
                  <span className="bg-purple-500 text-white px-3 py-1 rounded-full text-sm font-medium mb-4 inline-block">
                    Most Popular
                  </span>
                )}

                <h3 className="text-2xl font-bold text-white mb-2">
                  {plan.name}
                </h3>

                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">
                    ${plan.price}
                  </span>
                  <span className="text-gray-400">/month</span>
                  {plan.trialDays && (
                    <p className="text-sm text-purple-400 mt-2">
                      {FREE_TRIAL_DURATION} days free trial
                    </p>
                  )}
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-3 text-gray-300">
                      <Check className="w-5 h-5 text-purple-400 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  variant={isPro ? 'primary' : 'outline'}
                  size="lg"
                  className="w-full"
                  onClick={() => handlePlanSelect(id as PlanTier)}
                  disabled={isCurrentPlan}
                >
                  {isCurrentPlan ? 'Current Plan' : (
                    plan.price === 0 ? 'Get Started' : `Start ${FREE_TRIAL_DURATION}-Day Free Trial`
                  )}
                </Button>
              </div>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <p className="text-gray-400">
            All plans include our core features. Need a custom plan?{' '}
            <a href="/contact" className="text-purple-400 hover:text-purple-300">
              Contact us
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}