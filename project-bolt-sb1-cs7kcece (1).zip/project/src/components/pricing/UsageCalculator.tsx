import React, { useState } from 'react';
import { PRICING_PLANS, type PlanId } from '../../config/pricing';

interface UsageCalculatorProps {
  planId: PlanId;
}

export function UsageCalculator({ planId }: UsageCalculatorProps) {
  const [apiCalls, setApiCalls] = useState<number>(0);
  const [transactionVolume, setTransactionVolume] = useState<number>(0);
  const plan = PRICING_PLANS[planId];

  const calculateApiCallsCost = (calls: number): number => {
    if (calls <= plan.apiCalls.included) return 0;

    let cost = 0;
    let remainingCalls = calls - plan.apiCalls.included;

    for (const tier of plan.apiCalls.tiers) {
      const [min, max] = tier.range;
      const tierCalls = max === null 
        ? remainingCalls 
        : Math.min(remainingCalls, max - min + 1);
      
      if (tierCalls > 0) {
        cost += tierCalls * tier.rate;
        remainingCalls -= tierCalls;
      }
      
      if (remainingCalls <= 0) break;
    }

    return cost;
  };

  const calculateTransactionFees = (volume: number): number => {
    if (volume <= plan.transactionFees.included) return 0;
    const excessVolume = volume - plan.transactionFees.included;
    return excessVolume * plan.transactionFees.rate;
  };

  const totalCost = plan.basePrice + 
    calculateApiCallsCost(apiCalls) + 
    calculateTransactionFees(transactionVolume);

  return (
    <div className="bg-gray-800 rounded-xl p-6 mt-4">
      <h3 className="text-lg font-semibold text-white mb-4">
        Usage Calculator
      </h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Monthly API Calls
          </label>
          <input
            type="number"
            min="0"
            value={apiCalls}
            onChange={(e) => setApiCalls(Math.max(0, parseInt(e.target.value) || 0))}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white"
          />
          <p className="text-sm text-gray-400 mt-1">
            First {plan.apiCalls.included.toLocaleString()} calls included
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Monthly Transaction Volume ($)
          </label>
          <input
            type="number"
            min="0"
            value={transactionVolume}
            onChange={(e) => setTransactionVolume(Math.max(0, parseInt(e.target.value) || 0))}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white"
          />
          <p className="text-sm text-gray-400 mt-1">
            First ${plan.transactionFees.included.toLocaleString()} processed without fees
          </p>
        </div>

        <div className="border-t border-gray-700 pt-4">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-400">Base Price</span>
            <span className="text-white">${plan.basePrice}</span>
          </div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-400">API Usage Cost</span>
            <span className="text-white">${calculateApiCallsCost(apiCalls).toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm mb-4">
            <span className="text-gray-400">Transaction Fees</span>
            <span className="text-white">${calculateTransactionFees(transactionVolume).toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-lg font-semibold">
            <span className="text-white">Estimated Total</span>
            <span className="text-purple-400">${totalCost.toFixed(2)}/month</span>
          </div>
        </div>
      </div>
    </div>
  );
}