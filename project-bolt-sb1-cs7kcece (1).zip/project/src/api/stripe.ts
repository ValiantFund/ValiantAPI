import Stripe from 'stripe';
import { auth } from '../lib/firebase';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
  typescript: true,
});

export async function createCheckoutSession({
  priceId,
  userId,
  email,
}: {
  priceId: string;
  userId: string;
  email: string;
}) {
  // Verify the user is authenticated
  const token = await auth.currentUser?.getIdToken();
  if (!token) {
    throw new Error('User must be authenticated');
  }

  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    customer_email: email,
    client_reference_id: userId,
    success_url: `${window.location.origin}/dashboard/billing?success=true&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${window.location.origin}/dashboard/billing?canceled=true`,
    subscription_data: {
      metadata: {
        userId,
      },
    },
    metadata: {
      userId,
    },
  });

  return session;
}

export async function createCustomerPortalSession(customerId: string) {
  // Verify the user is authenticated
  const token = await auth.currentUser?.getIdToken();
  if (!token) {
    throw new Error('User must be authenticated');
  }

  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${window.location.origin}/dashboard/billing`,
  });

  return session;
}

export async function getSubscription(subscriptionId: string) {
  // Verify the user is authenticated
  const token = await auth.currentUser?.getIdToken();
  if (!token) {
    throw new Error('User must be authenticated');
  }

  return await stripe.subscriptions.retrieve(subscriptionId);
}