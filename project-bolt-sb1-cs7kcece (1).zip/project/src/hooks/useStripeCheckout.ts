import { useState } from 'react';
import { useAuth } from './useAuth';
import { redirectToCheckout } from '../lib/stripe/checkout';
import type { CheckoutError } from '../lib/stripe/errors';

export function useStripeCheckout() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startCheckout = async (priceId: string) => {
    if (!user?.email) {
      throw new Error('User must be authenticated');
    }

    try {
      setLoading(true);
      setError(null);
      
      await redirectToCheckout({
        priceId,
        userId: user.uid,
        email: user.email,
      });
    } catch (err) {
      const error = err as CheckoutError;
      setError(error.message || 'Failed to start checkout process');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    startCheckout,
    loading,
    error,
  };
}